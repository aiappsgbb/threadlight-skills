# SpecKit Template

> Adapted from ghcpsdk-process-builder for general-purpose business process specification.
> No runtime or SDK specifics — pure business + technical spec.

For the explicit `presenter-ready` delivery profile, SPEC sections 1/2/8b/11/12
reference the single process-owned `specs/presenter-contract.json` rather than
duplicating its facts. Follow [the delivery contract](../../../docs/presenter-ready.md):
role/problem/company, editable input, deterministic rules vs agent contribution,
bounded outcome/human responsibility, first action/readback/reopen/recovery,
exclusions, selected deployment consumer and sizing. Design the workspace with
that first journey. No profile means the existing template remains unchanged.
In the standalone Cowork bundle the same guide is `references/presenter-ready.md`
relative to the skill root; execution remains an engineering handoff.

```markdown
# SpecKit: [Process Name]

> Generated: [date]
> Status: draft | review | approved

## 1. Process Overview

**Name**: [Full process name]
**Domain**: [Industry or business domain]
**Description**: [2-3 sentences describing the process end-to-end]
**Target Persona**: [Who will see the demo — CIO, CFO, COO, CDO, CISO, Developer, or mixed]

### Audience & Customer Context

> Populated by `threadlight-design` Step 1.5 (Full mode). Fast-PoC mode
> leaves the placeholders unchanged and surfaces a callout in § 13.

- **`audience_mode`**: `external-demo | internal-pilot | third-party-build | unspecified`
  - `external-demo` — Microsoft seller / SE pitching a prospect (default for backwards compat)
  - `internal-pilot` — org's own IT team / centre-of-excellence building for its own users
  - `third-party-build` — SI / partner building inside a customer tenant
  - `unspecified` — preserve today's behaviour; treat as `external-demo` for prompts, flag in § 13

### Customer / Org

- **`customer.name`**: [Prospect for external-demo; own org for internal-pilot; partner org for third-party-build]
- **`customer.region`**: [e.g. EU, North America, APAC — drives data residency hints]
- **`customer.brand_palette`**:
  - **primary**: [hex color or "Threadlight neutral" if not collected]
  - **secondary**: [hex color or empty]
  - **logo_url**: [optional]
  - Empty / neutral is the default for `internal-pilot` and `third-party-build` unless the operator opts in.
- **`customer.tenant`** *(third-party-build only)*: [customer tenant the partner builds inside]

### Goals
- [Primary goal — what outcome does this deliver?]
- [Secondary goals]

### Scope
- **In scope**: [What's included]
- **Out of scope**: [What's excluded]

### Participants
| Role | Type | Description |
|------|------|-------------|
| | human / system / agent | |

> Type `human` = end user or stakeholder who interacts with the system
> Type `system` = external system the agent integrates with (SAP, CRM, DB, API, etc.)
> Type `agent` = the AI agent or one of its specialist skills

---

## 2. Process Flow

### Steps

#### Step 1: [Name]
- **Actor**: [Who performs this — agent, human, or system]
- **Input**: [What's needed to start this step]
- **Action**: [What happens]
- **Output**: [What's produced]
- **Decision**: [Branch conditions — if X → Step Y, if Z → Step W]

#### Step 2: [Name]
- **Actor**:
- **Input**:
- **Action**:
- **Output**:

> Add as many steps as needed. Keep each step atomic — one actor, one action.
> Decision branches should reference step numbers for clarity.

---

## 3. Business Rules

Number all rules BR-XXX. These drive evaluation scenarios and skill logic.

### BR-001: [Rule Name]
- **Condition**: [When does this rule apply?]
- **Action**: [What must happen?]
- **Exception**: [Any exceptions to the rule?]
- **KPI** (optional but recommended — see § 9 Business KPIs): [Name of the metric this rule influences, e.g. `auto_decline_rate`]

### BR-002: [Rule Name]
- **Condition**:
- **Action**:
- **Exception**:
- **KPI**:

> Business rules are the backbone of the spec. Every skill procedure and
> evaluation scenario should trace back to one or more BR-XXX rules.
>
> **Continuous evaluation contract:** every BR-XXX should map to at least one
> measurable KPI in § 9. The KPI is what the `microsoft-foundry` continuous loop
> watches week-over-week — `eval_dataset.jsonl` (one-shot) only proves the
> agent works in lab; KPIs prove it keeps working in production.

---

## 4. Data Models

Define the entities the process works with. These become the schema for mock data.

### [Entity Name]
| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| | string / int / float / bool / enum / datetime | yes/no | constraints | |

- **System of record**: [Which system from § 5 owns this entity — or "internal" if agent-managed]

> Include all entities: inputs, outputs, intermediate state, reference data.
> For enum fields, list valid values in the Validation column.
> The `System of record` links entities to integrations — entities backed by
> **mock** systems in § 5 will get sample data generated in `specs/sample-data/`.

---

## 5. System Integrations

External systems the process needs to interact with.

### [System Name]
- **Type**: database / API / SaaS / file-store / message-queue
- **Direction**: read / write / read-write
- **Data exchanged**: [What entities flow in/out]
- **Auth**: [Auth type — OAuth, API key, managed identity, none]
- **Availability**: available / auth-required / internal-only / **mock** ← for systems you can't access

> For systems marked **mock**: sample data will be generated in `specs/sample-data/`
> matching the data models above. When the real system becomes available, replace
> mock data with an MCP server or API connection.

---

## 5b. External Systems & Mocks (MCP contract)

> **INPUT CONTRACT for `threadlight-mcp-aca`.** This section drives the FastMCP server
> generation. Every tool the agent calls against an external system must be declared
> here with its endpoint shape, response semantics, and reset behavior.

For each system from § 5 that the agent will reach **via an MCP tool** (mock or real),
specify:

### [System Name]
- **MCP server**: `mock` (FastMCP backed by sample data) | `real` (deployed MCP) | `cosmos-toolkit` (10 built-in tools) | `playwright` (browser automation)
- **Endpoint shape**:
  - Style: `request-response` | `streaming` (SSE) | `webhook` (push from system)
  - Pagination: `none` | `cursor` | `offset-limit` | `keyset`
  - Idempotency key field: `[field name or "none"]`
- **Tools exposed** (one row per MCP tool — match § 6 contracts):
  | Tool name | Read/Write | Latency budget | Notes |
  |-----------|-----------|----------------|-------|
  | `get_customer_by_id` | R | <100ms | Backed by `customers.json` |
- **Mock data scale**: rows per entity (e.g. `customers: 50, orders: 200, ledger: 1000`)
- **Reset semantics**: `idempotent` (re-seed wipes + repopulates) | `append-only` (history preserved across runs) | `none` (read-only)
- **Demo state machine** (if any): list discrete demo states the data should cycle through (e.g. `pristine → mid-incident → resolved`) so the same seed file can drive a story.
- **Real-system swap notes**: what changes when the real backend appears (URL, auth header, schema differences).

> **Why a separate section?** § 5 is the business-level inventory ("we talk to SAP").
> § 5b is the developer-level contract ("here's exactly what the MCP server returns,
> at what shape, and how to reset it for a clean demo run"). The first is for stakeholders;
> the second is what `threadlight-mcp-aca` reads to generate code.

---

## 6. Tool Contracts

Define the tools the agent will use. These are abstract — not bound to any specific runtime.

### [tool_name]
- **Description**: [What does this tool do?]
- **Used by**: [Which skill/agent uses this]
- **Inputs**:
  | Parameter | Type | Required | Description |
  |-----------|------|----------|-------------|
  | | | | |
- **Output Schema**: `{ field: type, ... }`
- **Side Effects**: [Any state changes, external calls]
- **Error Cases**: [What can go wrong and how to handle it]
- **Backed by**: [System integration name from § 5, or "internal logic"]

---

## 7. Knowledge Sources

Reference documents, policies, or data the agent needs for reasoning.

### [Source Name]
- **Type**: document / database / search-index / API
- **Content**: [What information does it contain?]
- **Format**: PDF / DOCX / HTML / JSON / structured DB
- **Update Frequency**: [How often does it change?]
- **Backing service**: `foundry-iq` (Azure AI Search Knowledge Agent — agentic retrieval, query planning, citations) | `mcp-search` (live API search) | `inline-context` (small enough to paste into instructions)
- **Reasoning effort** (for foundry-iq): `minimal` | `low` | `medium` — drives Knowledge Agent config
- **Citation requirement**: `mandatory` (every answer must cite ≥1 source) | `recommended` | `optional`

> **Static / semi-static knowledge → `foundry-iq`.** Policies, regulations,
> product docs, brand guidelines, runbooks, technical specs — anything that
> changes monthly-or-slower and benefits from query planning + citations
> belongs in a Foundry IQ Knowledge Base. This is the **default knowledge
> retrieval pattern** for every threadlight process — even processes that
> primarily query transactional data should ship with a Foundry IQ index for
> their domain policies. See the `foundry-iq` skill for index design,
> document chunking, and Knowledge Agent reasoning levels.

### `knowledge_sources[]` (INPUT CONTRACT for `threadlight-ground`)

> **INPUT CONTRACT for `threadlight-ground`.** Declare every knowledge
> source the agent grounds answers on as a `knowledge_sources[]` entry —
> this is the machine-readable companion to the narrative `[Source Name]`
> blocks above, and it is what `threadlight-ground` sanitizes and assesses
> ACL/citation/refusal evidence against (`GRD-001..004`). Only the six
> fields below are ever persisted into `specs/ground-manifest.json`; add
> `acl_probe_principals` when you already know which principals should be
> probed for entitled/unentitled access.
>
> **Principals and permissions must be *verified*, never *inferred*.**
> Declaring `permission_model: acl` here is a design intent, not proof —
> it does not by itself demonstrate that access control is enforced.
> `threadlight-ground` requires an actual ACL probe run (captured by the
> operator, e.g. via a manual live handoff) naming real principals and the
> documents each one received; a source with no such run is reported
> `not-verified`, never a guessed `pass`. Likewise, do not name a principal
> "entitled"/"unentitled" here and assume that settles it — supply
> `expected_entitled` on the probe run itself so classification never
> relies on a naive name heuristic.

```yaml
knowledge_sources:
  - id:                          # unique within this SPEC, e.g. policy-library
    type:                        # documents | database | search-index | api
    permission_model:            # acl | public | none | rbac | custom
    refresh_cadence:             # hourly | daily | weekly | monthly | custom
    citation_required:           # bool — every answer grounded on this source must cite it
    refuse_when_unsupported:     # bool — refuse rather than answer when this source can't support the query
    acl_probe_principals:        # optional — principals threadlight-ground should probe, e.g. [entitled, unentitled]
```

Example — a policy library requiring ACL enforcement proof, refreshed
daily, with mandatory citations and mandatory refusal on unsupported
queries:

```yaml
knowledge_sources:
  - id: policy-library
    type: documents
    permission_model: acl
    refresh_cadence: daily
    citation_required: true
    refuse_when_unsupported: true
    acl_probe_principals: [entitled, unentitled]
```

---

## 7b. AI Services & Model Selection

> **INPUT CONTRACT for `azure-ai` and the model declarations in
> `azure.yaml` `config.deployments`.** Every model-backed capability the agent uses
> must be declared here so deployment can provision the right model SKU and capacity.

These are **runtime inference** choices, not the authoring host's model.
A lower-cost candidate may be evaluated on the same validated prototype using
the fixed-artifact procedure in `model-selection.md`; promote only against
predeclared thresholds and controls. The dated table is a starting point, not
an automatic downgrade rule or substitute for observed tool/skill execution.

For each AI capability the agent needs:

### [Capability Name]
- **Capability type**: `chat-reasoning` | `vision-structured-extract` | `vision-unstructured-reason` | `document-extract` | `speech-to-text` | `text-to-speech` | `embeddings`
- **Service**: `Azure OpenAI` (chat / vision / embeddings) | `Document Intelligence v4` (forms, IDs, invoices) | `Azure Speech` (STT / TTS) | `Azure Vision` (OCR, image analysis)
- **Model + version** (current as of 2026-05):
  | Use case | Recommended model | Notes |
  |----------|-------------------|-------|
  | **Default for threadlight pilots (7+ skills, 10+ tool calls)** | `gpt-5.4` (2026-03-05) | 1M context, vision-capable. Existing runtime starting point; confirm tool-call discipline on the actual artifact |
  | Trivial chat / 1-2 step flows; lower-cost A/B candidate | `gpt-5.4-mini` (2026-03-17) | 400K context, vision-capable, lower cost. Short chains are a useful first candidate, not a tool-count limit; longer chains need explicit execution evidence before promotion |
  | Premium reasoning + vision | `gpt-5.4-pro` (2026-03-05) | When vision feeds multi-step reasoning |
  | Bulk / cheap vision | `gpt-5.4-nano` (2026-03-17) | Returns triage, photo screening |
  | Code-related multimodal | `gpt-5.3-codex` (2026-02-24) | Diagrams → code |
  | Structured doc extract (passport, invoice, ID) | Document Intelligence v4 prebuilt | Use prebuilt when possible |
  | Custom doc extract | Document Intelligence v4 custom model | Train when prebuilt doesn't fit |
  | Voice intake | Azure Speech-to-Text (real-time) | n/a |
- **Capacity (TPM)**: e.g. `50K` GlobalStandard for `gpt-5.4`, `120K` for `gpt-5.4-mini`, `300K+` for high-volume
- **Reasoning effort** (for capable models): `minimal` | `low` | `medium` | `high` (default `medium`)

> **Do NOT use `GPT-4o` or `GPT-4o Vision`** — both are legacy as of May 2026.
> The `gpt-5.4` family supersedes them in every dimension (context, latency, vision
> quality, cost). If a SPEC carries forward a `GPT-4o` reference from an older
> template, that's a bug — sweep to **`gpt-5.4`** (default for pilots) or pick from
> the table above based on the capability profile.

> **Choosing the model / capacity / region behind this table** — see
> [`model-selection.md`](model-selection.md) in the design skill's references:
> the seven-decision procedure that fills `specs/foundation.md` § 2 and this
> section.

---

## 8. Human Interaction Points

Where humans are involved — approvals, escalations, input requests, feedback loops.

### [Interaction Name]
- **Trigger**: [When does this happen?]
- **Actor**: [Which human role?]
- **Channel**: [How — Teams, email, portal, chat?]
- **Data Presented**: [What the human sees]
- **Options**: [What actions can the human take?]
- **Timeout/SLA**: [How long before escalation?]
- **Action gate** (use the canonical taxonomy below): `approve` | `edit-and-approve` | `reject` | `escalate` | `signoff` | `audit-view` | `request-info`
  | Gate | Semantics | Typical UX |
  |------|-----------|------------|
  | `approve` | Yes/no on a proposed action | Adaptive Card with two buttons |
  | `edit-and-approve` | Human can amend the agent's proposal before approving | Editable form fields + approve button |
  | `reject` | Human refuses the action with a reason | Reason picker + free-text |
  | `escalate` | Human routes the case to a higher authority | Role/queue picker |
  | `signoff` | Human attests they reviewed (no veto) | Single confirm button + signature trail |
  | `audit-view` | Read-only inspection (no action taken) | Detail pane with audit log |
  | `request-info` | Human asks the customer/external party for more data | Templated message composer |
- **Linked business rules**: [BR-XXX list] — which rules require this gate

> **INPUT CONTRACT for `threadlight-hitl-patterns`.** The action gate
> drives Adaptive Card generation and bot UX. The linked BR-XXX list drives
> the audit trail wiring.

---

## 8b. Human Interaction (Workspace UX)

> **INPUT CONTRACT for `threadlight-workspace-ui`.** This section describes the
> case-management surface that humans use day-to-day — independent of the chat/Teams
> approval gates above. Skip this section if humans only interact via approval cards.

- **Workspace shape**: `case-list` (queue of items, filter/sort, click into detail) | `inbox` (chronological stream) | `dashboard` (KPI tiles + drill-down) | `console` (live ops with action toolbar) | `kanban` (stages with drag) | `map` (geo) | `none`
- **Primary filters**: list (e.g. status, owner, age, risk-band)
- **Detail pane sections** (top to bottom): list (e.g. summary card, agent reasoning trace, tool call log, decision history, action toolbar, audit viewer)
- **Action toolbar** — gates from § 8 that appear here (subset)
- **Audit viewer**: `inline` (always visible) | `drawer` (open on demand) | `none`
- **Bulk operations**: list (e.g. assign-to-me, batch-reject) — or `none`

---

## 9. Success Criteria

### Functional
- [ ] [Expected behavior — tied to business rules]

### Performance
- [Throughput, latency, SLA targets]

### Quality
- [Accuracy, error rates, coverage targets]

### Evaluation Scenarios

| ID | Scenario | Input | Expected Output | Business Rules | Category |
|----|----------|-------|-----------------|----------------|----------|
| S-001 | | | | BR-XXX | happy-path / edge-case / error / approval |

### Business KPIs (BR → KPI mapping)

> **INPUT CONTRACT for `microsoft-foundry` continuous-loop.** Every BR-XXX should
> map to at least one **measurable KPI** that can be computed from agent traces
> (Application Insights). This is what the continuous evaluation dashboard
> watches week-over-week — not just the binary scenario pass/fail.
>
> **Use the industry-native KPI vocabulary** from `references/data-realism/{industry}.md` § "<industry>-native KPIs". Generic names like `auto_decline_rate` should be the exception — most processes have a domain-recognized KPI an SME will accept on first read.

**Industry exemplars** (replace these with KPIs from the relevant industry file):

| Industry | Example KPI (good) | Example KPI (bad) |
|----------|--------------------|-------------------|
| FSI / AML | `alert_to_case_conversion_rate`, `l1_false_positive_rate`, `sar_filing_cycle_days_p50` | `decline_rate` |
| FSI / KYC | `edd_throughput_cases_per_analyst_per_day`, `first_touch_resolution_pct` | `auto_decline_rate` |
| Mfg / Plant | `oee_pct`, `first_pass_yield_pct`, `dpmo`, `capa_closure_cycle_days_p50` | `quality_score` |
| Mfg / Supply | `otif_pct_inbound`, `single_source_pct_of_spend` | `supply_score` |
| Retail / PIM | `pim_completeness_pct`, `time_to_publish_hours_p95` | `enrichment_rate` |
| Retail / Returns | `return_cycle_time_business_days_p50`, `restock_a_pct` | `return_resolution_rate` |
| Telco / Order | `order_fallout_rate_pct`, `fallout_mttr_hours_p50` | `order_success_rate` |
| Telco / Network | `mttr_hours_p1`, `first_call_resolution_pct` | `incident_resolution_rate` |

| BR | KPI Name | Formula (computable from traces) | Target | Alert threshold |
|----|----------|-----------------------------------|--------|-----------------|
| BR-001 | `<industry-native-kpi>` | `count(decisions where outcome=...) / count(decisions)` | (industry benchmark from data-realism file) | (alert when off-baseline) |
| BR-007 | `policy_citation_rate` | `count(answers where citations≥1) / count(answers)` | 100% | <95% |
| BR-012 | `human_escalation_rate` | `count(escalated) / count(decisions)` | (industry-realistic band) | (off-baseline) |

> Trace fields the agent must emit (declared in the skills' procedures):
> `decision.outcome`, `decision.business_rules_fired`, `answer.citations[]`,
> `escalation.reason`, etc. The continuous-loop ACA job pulls these from
> App Insights, computes KPIs, and writes back to a workbook + raises
> alerts on threshold breaches.

---

## 10. Trigger & Run Model

How and when the process executes.

- **Trigger**: [on-demand / scheduled / event-driven / continuous]
- **Schedule**: [If scheduled — cron expression or cadence]
- **Event source**: [If event-driven — what triggers it]
- **Expected volume**: [Requests per hour/day]
- **Latency/SLA**: [Max acceptable response time]
- **Concurrency**: [Parallel execution expected?]

### 10b. Triggers (Receiver contract)

> **INPUT CONTRACT for `threadlight-event-triggers`.** For event-driven and
> scheduled processes, declare the receiver shape so the right ACA job /
> Function / Event Grid sub / Service Bus consumer can be scaffolded.

| Trigger source | Receiver type | Idempotency key | Dedup window | Dead-letter rule |
|----------------|---------------|-----------------|--------------|------------------|
| Cron `0 6 * * *` | ACA Job | run timestamp | n/a | retry 3× then alert |
| Event Grid topic `orders/created` | Function (HTTP receiver) | `event.id` | 5 min | DLQ to Storage Queue |
| Service Bus queue `claims-incoming` | ACA consumer (Service Bus binding) | `MessageId` | 24h | move to `claims-poison` after 5 attempts |
| Webhook from external system | ACA Job (HTTP-triggered) | `X-Request-Id` header | 10 min | return 5xx to trigger sender retry |

> **Note for pilots:** event-driven triggers are **worth declaring** but **not mandatory
> to build for the first pilot** — the customer often integrates with their own event
> bus on their own terms. Ship the contract; let the integration follow.

---

## 11. Security, Compliance & Governance

- **PII involved**: yes / no — [if yes, what fields, with citation to the
  governing regime (HIPAA Safe Harbor § 164.514, GDPR Art 9, CPNI 47 CFR
  Part 64 Subpart U, PCI-DSS v4.0, etc.)]
- **Auth model**: [How users/systems authenticate — keyless / managed
  identity end-to-end is the default; any deviation is a flag]
- **Data residency**: [Customer expectation — `EU`, `US`, `UK`, `India`,
  `multi-region`. Names the Azure regions chosen. GDPR / PIPL / DPDPA
  compliance implications.]
- **Data retention**: [How long to keep agent traces, case data, audit
  events; deletion policy; right-to-be-forgotten path]
- **Regulatory**: [GDPR, HIPAA, SOX, FFIEC, MiFID II, PCI-DSS, ISO 27001,
  SOC 2 Type II, IATF 16949, GxP, ITAR/EAR, industry-specific — or
  `none` for internal automation only]
- **Access control**: [RBAC matrix — who can run this, who can see
  results. Reference Easy Auth / Entra ID groups by name.]
- **Audit requirements**: [What must be logged for auditability —
  decision rationale, citations, model+prompt version, human-overrides,
  upstream/downstream data lineage. Default: 7-year retention for
  regulated; 90-day for unregulated.]
- **Responsible AI posture**: [Risk tier per Microsoft RAI Standard v2
  (`limited`, `general`, `consequential`, `restricted`); applicable RAI
  goals — fairness, reliability, privacy, transparency, accountability;
  GDPR Art 22 (automated-decision rights) implications if applicable]
- **Model governance**: [Model + prompt version pinning; promotion gate
  from dev→prod (eval pass threshold); rollback procedure; drift
  monitoring cadence]
- **Customer onboarding RACI**: [Who on the customer side is **R**esponsible /
  **A**ccountable / **C**onsulted / **I**nformed for this process —
  business sponsor, IT owner, security/compliance signoff, legal/privacy,
  ops handoff. Demos that don't name a sponsor don't fund.]
- **ROI hypothesis**: [Quantifiable lever — `FTE-hours × loaded-rate`,
  `revenue-at-risk × probability`, `regulator-fine-avoided`, `cycle-time-
  compression × volume`. Cite the formula explicitly so the customer can
  replace the inputs with their own numbers.]
- **Change management**: [Org-side adoption plan — who trains the L1/L2
  analysts, how the agent's recommendations enter the existing workflow
  (parallel-run period? shadow-mode? full cutover?), what KPIs prove
  adoption stuck.]

### 11a. Runtime Governance Contract

> **INPUT CONTRACT for runtime governance design.** Validate this machine-readable
> fragment against `references/governance-contract.schema.json`. `governance.mode`
> exact contract text: `mode: off | selective | comprehensive`. `off` and `selective` are allowed;
> `comprehensive` is only valid when every consequential or unknown tool has a
> supported runtime binding. `off` means `lifecycle_bindings: []` and no bound
> tool records. `environment_modes only matter when mode != off`; `off` in
> `production-bound` is still allowed by design but does not make an enforcement
> claim. Legacy string tools remain valid where older
> manifests still permit them, but in this contract they are explicitly
> `unknown/unbound` until upgraded to the structured form below.
>
> **Layering vocabulary.** **SAFE is the methodology**. **ACS is the PDP**.
> **Agent Hooks is the runtime contract**. **host/gateway is the PEP**.
> **AGT is the toolkit**. **ASSERT is the assurance layer**. policy bundles, templates, and CI checks do not enforce runtime behavior on their own; they
> only prove whether the live PDP + PEP path is designed and verified correctly.

```yaml
framework: github-copilot-sdk | microsoft-agent-framework

governance:
  # Exact contract text:
  #   mode: off | selective | comprehensive
  mode: selective
  # environment_modes only matter when mode != off
  environment_modes:
    development: evaluate_only
    staging: evaluate_only
    preproduction: enforce
    production: enforce
  lifecycle_bindings:
    - lifecycle_point: input         # input | pre_model_call | post_model_call | pre_tool_call | post_tool_call | output | startup | shutdown
      policy_binding: request-ingress-v1
      enforcement_path: governed-tool-gateway
      safe_principles: [scope, audit]
      requires: [signed-policy-bundle]
    - lifecycle_point: output
      policy_binding: response-egress-v1
      enforcement_path: governed-tool-gateway
      safe_principles: [egress-review, audit]
      requires: [decision-receipt]

tools:
  - id: returns_get_case
    consequence: read                # read | write | external-egress | irreversible | unknown
    policy_binding: none             # use `none` only for an explicit unbound gap
    enforcement_path: none           # none | local-agent-hooks | governed-tool-gateway
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
  - id: returns_apply_decision
    consequence: write
    policy_binding: returns-write-v1
    enforcement_path: governed-tool-gateway
    intervention_points: [pre_tool_call, post_tool_call]
    safe_principles: [scope, approval, audit]
    requires: [human-approval-record, signed-policy-bundle]
  - id: legacy_export
    consequence: unknown
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [audit]
    requires: [operator-review]
    acceptance_record:
      owner: risk-owner@contoso.com
      justification: Temporary waiver while a supported binding is being onboarded.
      review_date: "2026-09-04T00:00:00Z"
      expiry: "2026-12-31T00:00:00Z"
```

- `development: evaluate_only` and `staging: evaluate_only` are fixed design-time
  expectations; `preproduction: enforce` and `production: enforce` are fixed
  release expectations when `mode != off`.
- If a tool can **write**, perform **external-egress**, or trigger an
  **irreversible** outcome, classify it explicitly and recommend the strongest
  supported binding.
- If the operator selected a runtime whose supported bindings cannot satisfy the
  recommended policy path, surface that as a design decision. Offer MAF if it
  would satisfy the requirement, but do not silently switch runtimes in the
  spec.
- `production-bound` unbound consequential or unknown tools require an
  `acceptance_record` with `owner`, `justification`, `review_date`, and
  `expiry`, both recorded as quoted RFC3339 timestamps. `off` is still allowed
  in `production-bound`, but it does not make an enforcement claim and any
  consequential or unknown unbound tool still needs acceptance.

### 11b. AI Governance Hub Posture (opt-in spoke)

> **INPUT CONTRACT for the optional governance-hub spoke handoff in
> `threadlight-deploy`.** Every regulated process should declare whether
> it needs to land as a spoke against an AI Governance Hub (e.g. an
> internal central LLM gateway / policy plane). The deploy flow generates
> the standalone agent first; if `governance_hub.required` is true,
> deploy then runs the spoke-onboarding handoff as a separate, opt-in
> step.

- **Governance hub spoke required**: `yes` (FSI, healthcare, regulated supplier risk) | `no` (PoC, internal automation)
- **Reason**: [Why — regulator audit, central LLM gateway policy, Key Vault federation, RAI policy enforcement, etc.]
- **Spoke artifacts needed**: list (e.g. `Access Contract`, `APIM connection`, `Key Vault secret federation`, `Product Policy`, `JWT auth`, `network whitelist`)
- **Tenant strategy**: `shared demo tenant` (default) | `dedicated customer tenant` | `customer-deferred`

---

## 11c. Tech Stack (Module selectors)

> **INPUT CONTRACT for `threadlight-deploy/references/azd-modules` Bicep module library and the
> composer in `threadlight-deploy`.** This selector vocabulary is the
> **canonical source of truth** — both the `threadlight-deploy/references/azd-modules` module library
> and the `threadlight-deploy` Phase-6 composer must read from this list
> verbatim. If you change a selector name, change it here first.
>
> Declare which infra modules the process needs. Don't list modules the
> process doesn't need (every selected module costs money).

| Module | Selected? | Purpose in this process |
|--------|-----------|-------------------------|
| `cosmos-db` | yes/no | Persistent case state, audit log, agent memory (no for stateless single-call agents) |
| `ai-search` | yes/no | Foundry IQ Knowledge Base backing |
| `doc-intel` | yes/no | Structured document extraction (passport, invoice, ID — when prebuilt model fits) |
| `azure-vision` | yes/no | OCR / image analysis (when not using GPT vision) |
| `azure-speech` | yes/no | Voice intake / TTS responses |
| `event-grid` | yes/no | Pub/sub for trigger events |
| `service-bus` | yes/no | Reliable queueing for case workflow |
| `storage-blob` | yes/no | Document upload, large artifacts, dataset hosting |
| `app-insights` | yes (default) | Telemetry — required for continuous evals |
| `aca-job` | yes/no | Scheduled / event-triggered batch work |
| `aca-mcp` | yes/no | Custom MCP server (mock or real) |
| `aca-bot` | yes/no | Teams bot |
| `foundry-iq-index` | yes/no | Pre-provisioned Knowledge Base + chunked corpus |

**Always-created** (not selectable): shared **UAMI** (managed identity),
the **Foundry project** + agent definition, the **ACR** for container
images.

**Implications** (the composer enforces these — declare them so SPEC
review can sanity-check):
- Selecting `aca-bot` implies `aca-mcp` (bot needs MCP for case lookups)
- Selecting `event-grid` or `service-bus` implies `aca-job` (you need a
  receiver)
- Selecting `foundry-iq-index` implies `ai-search` and `storage-blob`
- Selecting `azure-speech` with custom voice / custom model implies
  `azure-speech-custom-subdomain` (**IRREVERSIBLE** flag — the deploy
  script must surface a `--confirm-irreversible` confirmation)

**Keyless by mandate.** `key-vault` is **not** in the always-created or
default-selected list. Threadlight pilots use managed identity end-to-end
per the keyless-mandate; add Key Vault only when the process integrates
with a customer-side service that demands a literal API key (and document
that integration explicitly in § 5).

---

## 11d. Demo Data (Realism rules)

> **INPUT CONTRACT for `threadlight-demo-data-factory`.** Sample data shape
> beyond the basic schema in § 4.

- **Per-entity volume**: e.g. `customers: 50, orders: 200, alerts: 1000`
- **Distribution**: realistic skew (e.g. `80% low-risk / 15% medium / 5% high`)
- **Golden cases** (named, hand-curated for the demo script): e.g. `kyc-cardinal-aerospace-holdings` (premium corporate onboarding, edge-case UBO chain), `fault-pinewood-gnb-overload-2026-04-15` (cascading failure for the dashboard demo). Naming **must** follow the two-token-shift rule from `references/data-realism/README.md` — no `acme-*` or `contoso-*`.
- **Reset semantics**: `idempotent` | `append-only` | `none` (see § 5b)
- **Realism rules** (industry-specific — see `references/data-realism/{industry}.md`):
  - PII: [allowed / synthetic-only / none]
  - Vendor / brand names: [synonym-shifted / fully fictional]
  - Regulatory identifiers (SSN, IBAN, etc.): [valid-format-fake / pattern-only]
  - Geographic distribution: [single-country / multi-region / global]

---

## 11e. Workflow Model

> **INPUT CONTRACT for `threadlight-deploy` Phase 2.** Determines whether
> the deploy skill generates an Agent container or a DurableWorkflow
> container. Defaults to `agent` when absent. Also carries the
> `capability_signals` block that `threadlight-deploy`'s Runtime-policy
> pre-flight cross-checks against `specs/foundation.md § 1` before route
> validation — the two must stay consistent (see
> `references/runtime-policy.json`'s `blocked_when`).

```yaml
workflow_model: agent  # agent | workflow

capability_signals:                     # machine-readable booleans + unresolved markers runtime-policy.json keys on
  requires_toolbox: false               # curated multi-tool Foundry Toolbox (web_search, code_interpreter, ...)
  requires_custom_python_tools: false   # bespoke @tool Python functions beyond MCP passthroughs
  requires_file_generation: false       # agent must produce/return files (XLSX/PDF/CSV), not just text/JSON
  latency_sensitive_data_queries: false # sub-second/fast data lookups where MAF agent tooling outperforms
  unresolved_signals:                   # per-signal unknown marker — a listed name means its boolean above is a placeholder, not a decision
    - requires_toolbox
    - requires_custom_python_tools
    - requires_file_generation
    - latency_sensitive_data_queries
  source: open-question                 # provided | inferred | defaulted-after-skip | open-question | migrated-from-legacy-foundation | hand-crafted-deploy-inferred
```

- `agent` *(default)* — single agent with tools; `threadlight-deploy`
  generates `AGENTS.md` + Skills + a hosted-agent or ACA-agent container.
- `workflow` — deterministic multi-step orchestration; `threadlight-deploy`
  additionally generates `WORKFLOW.md` (executor / phase definitions) and
  scaffolds a DurableWorkflow container instead of a single agent. Use when
  the process has fixed phases, long-running waits, retries with explicit
  back-off, or human approvals between stages.

> **Deriving `capability_signals`.** Set each boolean from what discovery
> actually found: `false` only when the requirement or tooling is **confirmed
> absent**, never merely unknown. If discovery cannot determine a signal yet,
> leave its name in `unresolved_signals` (`source: open-question`) instead of
> guessing `false`. As each signal resolves, **remove** its name from
> `unresolved_signals` and set its boolean accurately — an **empty**
> `unresolved_signals` list means all four are resolved. This block mirrors
> `specs/foundation.md § 1` verbatim; the two must stay consistent. **Refuse**
> to honor an explicit `explicit-supported-choice` GHCP override while
> `unresolved_signals` is non-empty (`runtime-policy.json`'s
> `requires_resolved_signals` gate on that route) — an unresolved signal could
> still turn out to be the one a `blocked_when` route owns.

---

## 11f. Deployment Posture

> **INPUT CONTRACT for `threadlight-deploy` Phase 1.5.** When this block is
> populated, Phase 1.5 takes **Path 1** — proceed with matching posture
> defaults, no operator prompt. When absent, Phase 1.5 asks the operator
> once and writes the answers to `specs/deployment-posture.md`.
> Pre-populated by `threadlight-design` Step 1.5 (Full mode); left empty
> by Fast-PoC.

```yaml
deployment_posture:
  deployment_target: demo-sandbox | customer-pilot | production-bound
  source: provided | inferred | defaulted-after-skip | open-question
  overrides:
    networking: public | private-required | deferred
    replicas: single | ha-min-replicas
    retention: 90d | regulated-7y | customer-defined
    model_pinning: preview-ok | ga-pinned
  deferred_decisions:
    - waf-front-door
    - dr-runbook
```

- `deployment_target` is the primary lever. The other rows are
  posture-tuning overrides; each may be omitted (deploy applies the
  defaults for the chosen target).
- `source` documents how the value was reached — same taxonomy as § 13.
- `deferred_decisions` lists rows the operator acknowledged but cannot
  implement in this pilot's scope (e.g. WAF / Front Door, paired-region
  DR). `threadlight-deploy` surfaces them as
  `<!-- TODO(posture): ... -->` comments in `main.bicep`.

**Authority order** (drift mitigation): SPEC § 11f → `specs/deployment-posture.md`
→ `azd env` vars. On rerun, `threadlight-deploy` Phase 1.5 reads the
posture file first; if § 11f also exists and disagrees, it surfaces the
conflict and asks which wins.

---

## 12. Production Readiness

> **INPUT CONTRACT for `threadlight-production-ready`.** Populated by
> default in the design template — fill in the placeholders before the
> pilot moves into customer architecture review. The production-readiness
> skill reads this block to resolve the target posture (Citadel spoke /
> AGT / standard AI gateway / hybrid), to score residency and SLA
> commitments, and to drive the customer-facing hand-off report.
> Pilots that ship with this section empty default to
> `target_posture: standard-ai-gateway` and trigger a "Recommended
> enterprise posture: Citadel-spoke" callout in the report.

- **target_posture**: `citadel-spoke` | `agt` | `standard-ai-gateway` | `hybrid` | `unset`
  - Citadel-spoke = the recommended enterprise default when the customer
    has (or is bringing) an AI Hub Gateway. AGT = in-process middleware
    where there is no hub. Standard AI gateway = third-party fallback.
    Hybrid = both AGT and an upstream APIM hub.
- **residency**: `EU` | `US` | `UK` | `India` | `multi-region` (cite the chosen Azure regions)
- **rto**: `4h` | `1h` | `15m` | … (recovery time objective)
- **rpo**: `1h` | `15m` | `0` (recovery point objective; `0` means synchronous replication required)
- **sla**: `99.5` | `99.9` | `99.95` (% availability target)
- **incident_owner**: `oncall@customer.com` (single mailbox / on-call rotation; not "TBD")
- **production_track**: `pilot-to-prod-2-week` | `production-hardening-6-week` | `not-bound` (timeline declared by customer)
- **must-have pillars**: list — pick from `network-posture, agent-governance, identity-access, secrets, observability, continuous-evals, responsible-ai, hitl-audit, supply-chain, cost, reliability, sre-handover, model-lifecycle`
- **CISO sign-off required**: `yes` (regulated industry, customer-data) | `no` (internal automation, demo-only)
- **Waiver acceptors**: list of names+titles (people who can sign off a waiver). Empty = nobody can; every gap is a hard block.

### `load_profile{}` (consumed by `threadlight-consumption-iq`)

> **Seed from qualification when available.** If a
> `qualification/sizing-manifest.json` exists (produced by `threadlight-qualify`),
> seed this block directly from its normalized `load_profile` instead of
> repeating the interview — copy `workload_class`, `peak_requests_per_second`,
> `business_hours_only`, `pages_per_month`/`storage_gb_year_one`, and the pinned
> region across, and record the sizing manifest as the provenance. Only fall
> back to the `threadlight-consumption-iq` wizard when no sizing manifest exists.
>
> Until either is run, recommendations and projections are not produced.

```yaml
load_profile:
  workload_class:               # chat-agent | batch | scheduled | hybrid
  peak_concurrent_sessions:     # int >= 1
  avg_requests_per_session:     # int >= 1
  avg_tokens_per_request:       # int >= 1 (combined input + output)
  peak_requests_per_second:     # float >= 0
  business_hours_only:          # bool
  cosmos_gb_year_one:           # float >= 0
  storage_gb_year_one:          # float >= 0
  ai_search_documents:          # int >= 0
  monthly_growth_rate:          # float >= 0 (e.g. 0.15 = 15%/mo)
  declared_constraints:
    max_p95_latency_ms:         # int >= 0
    min_redundancy:             # none | zone-redundant | geo-redundant
    pinned_region:              # optional; ISO Azure region like eastus2
```

> See `skills/threadlight-production-ready/references/spec-section-12-template.md`
> for two fully-worked examples (Citadel-spoke FSI customer and AGT-only
> internal automation).

---

## 13. Assumptions & Open Questions

> **Source-taxonomy table.** Every captured-context item from § 1
> (`audience_mode`, `customer.*`), every § 11f posture override, and any
> downstream-skill default that was applied without explicit input MUST
> appear here with a `Source` value of `provided | inferred |
> defaulted-after-skip | open-question`. This is the auditable trail of
> silently-defaulted decisions.

### Captured-context source table

| Field                          | Effective value                      | Source                | Default used? | Follow-up needed |
|--------------------------------|--------------------------------------|-----------------------|---------------|------------------|
| § 1.audience_mode              | [e.g. external-demo]                 | [provided / inferred / defaulted-after-skip / open-question] | yes / no | yes / no |
| § 1.customer.name              | [e.g. Contoso Retail]                | provided              | no            | no               |
| § 1.customer.region            | [e.g. EU]                            | provided              | no            | no               |
| § 1.customer.brand_palette     | [e.g. Threadlight neutral]           | defaulted-after-skip  | yes           | no               |
| § 11f.deployment_target        | [e.g. customer-pilot]                | provided              | no            | no               |
| § 11f.overrides.networking     | [e.g. public]                        | defaulted-after-skip  | yes           | yes              |

> Fast-PoC mode callout *(include verbatim when Step 1.5 was skipped)*:
> _Fast-PoC mode: audience mode, customer context, brand, and production
> posture were not collected; using neutral demo defaults. Override later
> in SPEC § 1 / § 11f / § 13._

> **Also add this row to the table above whenever § 14 ships blank** —
> always in Fast-PoC mode, and in Full mode whenever the operator has not
> yet confirmed `success_event` and the cost/variance thresholds. This is
> not a silent default (`Default used? no`): § 14 has no defaults at all,
> so leaving it blank is always the honest, correct state; this row is what
> makes that state auditable rather than merely implicit.
>
> | § 14.value_model | not collected | open-question | no | yes |
>
> **Full mode's job is to ask the operator to state and confirm
> `success_event` and every `baseline`/`maturity_policy`/`accounting`
> threshold explicitly, or to explicitly defer them here** — never to
> arbitrarily derive a number or event name just to avoid this row.

### Assumptions
- [Assumption 1 — something taken as given]
- [Assumption 2]

### Open Questions
- [Question 1 — needs stakeholder input]
- [Question 2]

### Dependencies
- [Dependency 1 — external system, team, or timeline]
- [Dependency 2]

---

## 14. Value Model

> **INPUT CONTRACT for the design → deploy cost-actuals reconciliation
> contract.** See `references/value-model-schema.md` for the full
> field-by-field schema, bounds, and rationale. This section is a **blank
> shape** — every field below is a bare YAML key, at most followed by a
> comment describing its type/bounds. Comments are not values: never invent
> a number to fill a placeholder. Copy the *shape* below, never the worked
> numbers from `examples/returns-triage-governed/specs/SPEC.md § 14` —
> those are specific to that pilot's return-triage economics and would be a
> fabricated default for any other pilot.
>
> **Full mode**: ask the operator to state and confirm each `maturity_policy`,
> `success_event`, `baseline`, and `accounting` field explicitly.
> `success_event` (`name` / `trace_attribute` / `success_values`) is always
> **operator-confirmed** in Full mode — never inferred from a BR-XXX business
> rule or guessed from the process description. A field the operator cannot
> answer yet stays blank and gets a row in § 13 Open Questions with
> `Source: open-question` — not a guessed number.
>
> **Fast-PoC mode**: emit this section's shape verbatim (every leaf blank,
> `success_event` included) and leave the source open in § 13 — unlike
> § 12's `target_posture`, this section has no silent default. An incomplete
> `maturity_policy` yields a `not-verified` cost verdict downstream, but the
> projection and actuals evidence artifacts are still produced and written;
> only the pass/fail verdict is withheld until the policy is satisfied.

```yaml
value_model:
  cost:
    maturity_policy:
      min_complete_days:                       # int >= 1
      min_successful_interactions:              # int >= 1
      min_cost_settlement_age_hours:            # int >= 0
      max_window_end_age_days:                  # int >= 1
      min_projection_attribution_coverage_pct:  # float, (0, 1] — this is
                                                 # PROJECTION attribution
                                                 # coverage, not actual
                                                 # resource-id coverage; only
                                                 # projection coverage is
                                                 # policy-gated here
    success_event:
      name:              # identifier: ^[A-Za-z][A-Za-z0-9_.:-]{0,127}$
                          # operator-confirmed in Full mode; never inferred
      trace_attribute:    # identifier: ^[A-Za-z][A-Za-z0-9_.:-]{0,127}$
                          # operator-confirmed in Full mode; never inferred
      success_values: []  # nonempty list of the same identifier grammar;
                          # operator-confirmed in Full mode; never inferred
    baseline:
      target_cost_per_successful_interaction_usd:  # float > 0; USD per
                                                     # successful interaction
                                                     # (as defined by
                                                     # success_event); no
                                                     # default
      max_forecast_variance_pct:                   # float, fractional [0, 1]
                                                     # (0.20 = 20%); no default;
                                                     # values > 1 are invalid —
                                                     # COST variance only
      max_token_volume_variance_pct:                # float, fractional [0, 1]
                                                     # (0.20 = 20%); no default;
                                                     # values > 1 are invalid —
                                                     # TOKEN VOLUME variance
                                                     # only; a distinct
                                                     # threshold from cost
                                                     # variance
    accounting:
      actual_cost_basis: usage-pretax    # literal; a metric/source, not a price basis
      actual_billing_price_basis:        # retail | ea | mca | unknown
      forecast_price_basis:              # retail | ea | mca
      allow_basis_mismatch_for_verdict:  # bool
      scope_policy:                      # dedicated_resource_group | tagged_allocation
```

> **Why `success_event.name` / `trace_attribute` / `success_values` are
> restricted to `^[A-Za-z][A-Za-z0-9_.:-]{0,127}$`**: these identifiers are
> compiled into a fixed AppTraces KQL query by the reconciliation code — the
> code never builds arbitrary KQL from operator input. Anything outside this
> grammar is rejected before it reaches the query string, not sanitized
> inside it. All three fields are **operator-confirmed** in Full mode and
> blank/open-question in Fast-PoC — never derived from a business rule or
> invented to look complete.
>
> **Why `max_forecast_variance_pct` / `max_token_volume_variance_pct` are
> fractional, not percentage integers**: `0.20` means 20%. Both fields are
> bounded to `[0, 1]`; a value greater than `1` (for example `20`, meant as
> "20 percent") is invalid and must be rejected, never silently
> reinterpreted. Neither field has a default.
>
> **Why `actual_billing_price_basis` is a required, explicit operator
> declaration and not derived**: the Cost Management Query API returns
> actual spend without telling you which price basis (retail / EA / MCA)
> produced it. The operator must state it. `unknown` is a valid but
> conservative choice — it is always treated as a basis mismatch against
> `forecast_price_basis` unless `allow_basis_mismatch_for_verdict: true`.
```
