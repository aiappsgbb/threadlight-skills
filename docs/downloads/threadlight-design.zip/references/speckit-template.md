# SpecKit Template

> Adapted from ghcpsdk-process-builder for general-purpose business process specification.
> No runtime or SDK specifics — pure business + technical spec.

For the explicit `presenter-ready` delivery profile, SPEC sections 1/2/8b/11/12
reference the single process-owned `specs/presenter-contract.json` rather than
duplicating its facts. Follow [the delivery contract](../../../docs/presenter-ready.md):
role/problem/company, editable input, deterministic rules vs agent contribution,
bounded outcome/human responsibility, first action/readback/reopen/recovery,
exclusions, selected deployment consumer and sizing. Design the workspace with
that first journey. No profile means the existing template remains unchanged.
In the standalone Cowork bundle the same guide is `references/presenter-ready.md`
relative to the skill root; execution remains an engineering handoff.

```markdown
# SpecKit: [Process Name]

> Generated: [date]
> Status: draft | review | approved

## 1. Process Overview

**Name**: [Full process name]
**Domain**: [Industry or business domain]
**Description**: [2-3 sentences describing the process end-to-end]
**Target Persona**: [Who will see the demo — CIO, CFO, COO, CDO, CISO, Developer, or mixed]

### Audience & Customer Context

> Populated by `threadlight-design` Step 1.5 (Full mode). Fast-PoC mode
> leaves the placeholders unchanged and surfaces a callout in § 13.

- **`audience_mode`**: `external-demo | internal-pilot | third-party-build | unspecified`
  - `external-demo` — Microsoft seller / SE pitching a prospect (default for backwards compat)
  - `internal-pilot` — org's own IT team / centre-of-excellence building for its own users
  - `third-party-build` — SI / partner building inside a customer tenant
  - `unspecified` — preserve today's behaviour; treat as `external-demo` for prompts, flag in § 13

### Customer / Org

- **`customer.name`**: [Prospect for external-demo; own org for internal-pilot; partner org for third-party-build]
- **`customer.region`**: [e.g. EU, North America, APAC — drives data residency hints]
- **`customer.brand_palette`**:
  - **primary**: [hex color or "Threadlight neutral" if not collected]
  - **secondary**: [hex color or empty]
  - **logo_url**: [optional]
  - Empty / neutral is the default for `internal-pilot` and `third-party-build` unless the operator opts in.
- **`customer.tenant`** *(third-party-build only)*: [customer tenant the partner builds inside]

### Goals
- [Primary goal — what outcome does this deliver?]
- [Secondary goals]

### Scope
- **In scope**: [What's included]
- **Out of scope**: [What's excluded]

### Participants
| Role | Type | Description |
|------|------|-------------|
| | human / system / agent | |

> Type `human` = end user or stakeholder who interacts with the system
> Type `system` = external system the agent integrates with (SAP, CRM, DB, API, etc.)
> Type `agent` = the AI agent or one of its specialist skills

---

## 2. Process Flow

### Steps

#### Step 1: [Name]
- **Actor**: [Who performs this — agent, human, or system]
- **Input**: [What's needed to start this step]
- **Action**: [What happens]
- **Output**: [What's produced]
- **Decision**: [Branch conditions — if X → Step Y, if Z → Step W]

#### Step 2: [Name]
- **Actor**:
- **Input**:
- **Action**:
- **Output**:

> Add as many steps as needed. Keep each step atomic — one actor, one action.
> Decision branches should reference step numbers for clarity.

---

## 3. Business Rules

Number all rules BR-XXX. These drive evaluation scenarios and skill logic.

### BR-001: [Rule Name]
- **Condition**: [When does this rule apply?]
- **Action**: [What must happen?]
- **Exception**: [Any exceptions to the rule?]
- **Output**: [What the agent's response must state when this rule fires. For escalation, routing or rejection rules, name the matched entity, party or record and the condition it met, e.g. "EDD: related party Ivan Gromov is a PEP (beneficial owner, 30%)"]
- **KPI** (optional but recommended — see § 9 Business KPIs): [Name of the metric this rule influences, e.g. `auto_decline_rate`]

### BR-002: [Rule Name]
- **Condition**:
- **Action**:
- **Exception**:
- **Output**:
- **KPI**:

> Business rules are the backbone of the spec. Every skill procedure and
> evaluation scenario should trace back to one or more BR-XXX rules.
>
> **Output contract:** when a rule escalates, routes or rejects, its **Output**
> must name the matched entity, party or record and the condition it met. A
> generic "escalated to EDD" without the triggering name is not actionable for the
> reviewer and fails the evaluation case that checks for it.
>
> **Continuous evaluation contract:** every BR-XXX should map to at least one
> measurable KPI in § 9. The KPI is what the `microsoft-foundry` continuous loop
> watches week-over-week — `eval_dataset.jsonl` (one-shot) only proves the
> agent works in lab; KPIs prove it keeps working in production.

---

## 4. Data Models

Define the entities the process works with. These become the schema for mock data.

### [Entity Name]
| Field | Type | Required | Validation | Description |
|-------|------|----------|------------|-------------|
| | string / int / float / bool / enum / datetime | yes/no | constraints | |

- **System of record**: [Which system from § 5 owns this entity — or "internal" if agent-managed]

> Include all entities: inputs, outputs, intermediate state, reference data.
> For enum fields, list valid values in the Validation column.
> The `System of record` links entities to integrations — entities backed by
> **mock** systems in § 5 will get sample data generated in `specs/sample-data/`.

---

## 5. System Integrations

External systems the process needs to interact with.

### [System Name]
- **Type**: database / API / SaaS / file-store / message-queue
- **Direction**: read / write / read-write
- **Data exchanged**: [What entities flow in/out]
- **Auth**: [Auth type — OAuth, API key, managed identity, none]
- **Availability**: available / auth-required / internal-only / **mock** ← for systems you can't access

> For systems marked **mock**: sample data will be generated in `specs/sample-data/`
> matching the data models above. When the real system becomes available, replace
> mock data with an MCP server or API connection.

---

## 5b. External Systems & Mocks (MCP contract)

> **INPUT CONTRACT for `threadlight-mcp-aca`.** This section drives the FastMCP server
> generation. Every tool the agent calls against an external system must be declared
> here with its endpoint shape, response semantics, and reset behavior.

For each system from § 5 that the agent will reach **via an MCP tool** (mock or real),
specify:

### [System Name]
- **MCP server**: `mock` (FastMCP backed by sample data) | `real` (deployed MCP) | `cosmos-toolkit` (10 built-in tools) | `playwright` (browser automation)
- **Endpoint shape**:
  - Style: `request-response` | `streaming` (SSE) | `webhook` (push from system)
  - Pagination: `none` | `cursor` | `offset-limit` | `keyset`
  - Idempotency key field: `[field name or "none"]`
- **Tools exposed** (one row per MCP tool — match § 6 contracts):
  | Tool name | Read/Write | Latency budget | Notes |
  |-----------|-----------|----------------|-------|
  | `get_customer_by_id` | R | <100ms | Backed by `customers.json` |
- **Mock data scale**: rows per entity (e.g. `customers: 50, orders: 200, ledger: 1000`)
- **Reset semantics**: `idempotent` (re-seed wipes + repopulates) | `append-only` (history preserved across runs) | `none` (read-only)
- **Demo state machine** (if any): list discrete demo states the data should cycle through (e.g. `pristine → mid-incident → resolved`) so the same seed file can drive a story.
- **Real-system swap notes**: what changes when the real backend appears (URL, auth header, schema differences).

> **Why a separate section?** § 5 is the business-level inventory ("we talk to SAP").
> § 5b is the developer-level contract ("here's exactly what the MCP server returns,
> at what shape, and how to reset it for a clean demo run"). The first is for stakeholders;
> the second is what `threadlight-mcp-aca` reads to generate code.

---

## 6. Tool Contracts

Define the tools the agent will use. These are abstract — not bound to any specific runtime.

> **Machine-read contract.** `threadlight-deploy` (including generate-only mode)
> builds the MCP server from this section. Each `` ### `tool_name` `` subsection's
> **Inputs** is canonical: one row (or one `` `name: type` required|optional ``
> item) per real argument. If you also keep a summary table, its input cell must
> repeat the real argument names; never write `none`, `see below` or `n/a` there.
> A tool with genuinely no inputs writes `none` (not `see below`).
> Read/write classification comes from § 5b (Read/Write column) and § 11a
> (`consequence:`), which win over any name-based guess; keep them consistent.
> Without them, a **Side Effects** bullet makes the tool a write unless it is
> exactly `none`, `no state changes`, `no writes`, `read-only` or similar
> (optionally with a qualifier such as `(read-only lookup)`); any further
> clause, such as "None; issues a refund", is a declared effect. Give each tool its own level-3 heading with the tool name in
> backticks (two names separated by `/` when they share one contract): in a recommend-only
> or governed-write pilot every § 6 heading or tool-table row that is not a parseable tool
> contract is a gap.

### `[tool_name]`
- **Description**: [What does this tool do?]
- **Used by**: [Which skill/agent uses this]
- **Inputs**:
  | Parameter | Type | Required | Description |
  |-----------|------|----------|-------------|
  | | | | |
- **Output Schema**: `{ field: type, ... }`
- **Side Effects**: [Any state changes, external calls]
- **Error Cases**: [What can go wrong and how to handle it]
- **Backed by**: [System integration name from § 5, or "internal logic"]

---

## 7. Knowledge Sources

Reference documents, policies, or data the agent needs for reasoning.

### [Source Name]
- **Type**: document / database / search-index / API
- **Content**: [What information does it contain?]
- **Format**: PDF / DOCX / HTML / JSON / structured DB
- **Update Frequency**: [How often does it change?]
- **Backing service**: `foundry-iq` (Azure AI Search Knowledge Agent — agentic retrieval, query planning, citations) | `mcp-search` (live API search) | `inline-context` (small enough to paste into instructions)
- **Reasoning effort** (for foundry-iq): `minimal` | `low` | `medium` — drives Knowledge Agent config
- **Citation requirement**: `mandatory` (every answer must cite ≥1 source) | `recommended` | `optional`
- **Enrichment**: `none` (default) | `entity_graph` (Foundry IQ entity graph, preview) — set by the graph-or-not rule below; mirrored in `knowledge_sources[].enrichments`

> **Static / semi-static knowledge → `foundry-iq`.** Policies, regulations,
> product docs, brand guidelines, runbooks, technical specs — anything that
> changes monthly-or-slower and benefits from query planning + citations
> belongs in a Foundry IQ Knowledge Base. This is the **default knowledge
> retrieval pattern** for every threadlight process — even processes that
> primarily query transactional data should ship with a Foundry IQ index for
> their domain policies. See the `foundry-iq` skill for index design,
> document chunking, and Knowledge Agent reasoning levels.

> **Graph or not (Foundry IQ entity graph, preview).** Add an entity graph,
> as a **graph + text** knowledge base (a graph source next to the text
> source, never graph only), only when **all** of these hold:
>
> 1. the § 9 acceptance questions chain facts across documents (multi-hop,
>    negation, aggregation), not single lookups;
> 2. every knowledge-base reader is entitled to the whole corpus, because the
>    graph carries no per-user permissions in this preview (`GRD-005`);
> 3. the relations live in prose, not already in structured data, where
>    Fabric IQ or SQL is the better fit;
> 4. preview status and build time (minutes per few hundred documents) are
>    acceptable for the pilot.
>
> Otherwise keep the default single knowledge base with
> `enrichments: [none]`. In our November 2026 test (synthetic corpus, 669
> documents) graph + text answered 32/34 questions against 21/34 for a plain
> knowledge base, with similar retrieval latency; on 69 documents the plain
> knowledge base already scored 31–33/34 because it returned almost the whole
> corpus. See the
> [entity graph how-to](https://learn.microsoft.com/azure/search/agentic-knowledge-source-how-to-entity-graph)
> and the [graph overview](https://learn.microsoft.com/azure/search/knowledge-graph-features-overview).

### `knowledge_sources[]` (INPUT CONTRACT for `threadlight-ground`)

> **INPUT CONTRACT for `threadlight-ground`.** Declare every knowledge
> source the agent grounds answers on as a `knowledge_sources[]` entry —
> this is the machine-readable companion to the narrative `[Source Name]`
> blocks above, and it is what `threadlight-ground` sanitizes and assesses
> ACL/citation/refusal evidence against (`GRD-001..005`). Only the six
> required fields and the optional `acl_probe_principals`, `enrichments`,
> `audience` and `revocation_settle_minutes` are persisted into
> `specs/ground-manifest.json` (never `audience_justification`); add
> `acl_probe_principals` when you already know which principals should be
> probed for entitled/unentitled access.
>
> **Principals and permissions must be *verified*, never *inferred*.**
> Declaring `permission_model: acl` here is a design intent, not proof —
> it does not by itself demonstrate that access control is enforced.
> `threadlight-ground` requires an actual ACL probe run (captured by the
> operator, e.g. via a manual live handoff) naming real principals and the
> documents each one received; a source with no such run is reported
> `not-verified`, never a guessed `pass`. Likewise, do not name a principal
> "entitled"/"unentitled" here and assume that settles it — supply
> `expected_entitled` on the probe run itself so classification never
> relies on a naive name heuristic. An ACL source also needs one probe with
> `token_mode: none` (no user token reaches retrieval) that returns no
> protected document, and a revocation probe counts only when captured at
> least `revocation_settle_minutes` (default 15) after `rbac_changed_at`.
>
> **Derived artifacts do not inherit document permissions.** A Foundry IQ
> entity graph or topic graph built from a source is readable by every
> knowledge-base reader. `permission_model: acl` with any `enrichments` other
> than `none` is `GRD-005` must-fix unless every reader is entitled to the
> whole corpus and you declare `audience: uniform` with an
> `audience_justification`.

```yaml
knowledge_sources:
  - id:                          # unique within this SPEC, e.g. policy-library
    type:                        # documents | database | search-index | api
    permission_model:            # acl | public | none | rbac | custom
    refresh_cadence:             # hourly | daily | weekly | monthly | custom
    citation_required:           # bool — every answer grounded on this source must cite it
    refuse_when_unsupported:     # bool — refuse rather than answer when this source can't support the query
    acl_probe_principals:        # optional — principals threadlight-ground should probe, e.g. [entitled, unentitled]
    enrichments:                 # optional — [none] (default) | [entity_graph] | [topic_graph] | [entity_graph, topic_graph]
    audience:                    # optional — uniform: every KB reader may read the whole corpus
    audience_justification:      # required with audience: uniform — stays in the SPEC, never persisted
    revocation_settle_minutes:   # optional — RBAC propagation wait before a denial probe counts (default 15)
```

Example — a policy library requiring ACL enforcement proof, refreshed
daily, with mandatory citations and mandatory refusal on unsupported
queries:

```yaml
knowledge_sources:
  - id: policy-library
    type: documents
    permission_model: acl
    refresh_cadence: daily
    citation_required: true
    refuse_when_unsupported: true
    acl_probe_principals: [entitled, unentitled]
```

---

## 7b. AI Services & Model Selection

> **INPUT CONTRACT for `azure-ai` and the model declarations in
> `azure.yaml` `config.deployments`.** Every model-backed capability the agent uses
> must be declared here so deployment can provision the right model SKU and capacity.

These are **runtime inference** choices, not the authoring host's model.
A lower-cost candidate may be evaluated on the same validated prototype using
the fixed-artifact procedure in `model-selection.md`; promote only against
predeclared thresholds and controls. The dated table is a starting point, not
an automatic downgrade rule or substitute for observed tool/skill execution.

For each AI capability the agent needs:

### [Capability Name]
- **Capability type**: `chat-reasoning` | `vision-structured-extract` | `vision-unstructured-reason` | `document-extract` | `speech-to-text` | `text-to-speech` | `embeddings`
- **Service**: `Azure OpenAI` (chat / vision / embeddings) | `Document Intelligence v4` (forms, IDs, invoices) | `Azure Speech` (STT / TTS) | `Azure Vision` (OCR, image analysis)
- **Model + version** (current as of 2026-05):
  | Use case | Recommended model | Notes |
  |----------|-------------------|-------|
  | **Default for threadlight pilots (7+ skills, 10+ tool calls)** | `gpt-5.4` (2026-03-05) | 1M context, vision-capable. Existing runtime starting point; confirm tool-call discipline on the actual artifact |
  | Trivial chat / 1-2 step flows; lower-cost A/B candidate | `gpt-5.4-mini` (2026-03-17) | 400K context, vision-capable, lower cost. Short chains are a useful first candidate, not a tool-count limit; longer chains need explicit execution evidence before promotion |
  | Premium reasoning + vision | `gpt-5.4-pro` (2026-03-05) | When vision feeds multi-step reasoning |
  | Bulk / cheap vision | `gpt-5.4-nano` (2026-03-17) | Returns triage, photo screening |
  | Code-related multimodal | `gpt-5.3-codex` (2026-02-24) | Diagrams → code |
  | Structured doc extract (passport, invoice, ID) | Document Intelligence v4 prebuilt | Use prebuilt when possible |
  | Custom doc extract | Document Intelligence v4 custom model | Train when prebuilt doesn't fit |
  | Recorded-audio transcription (files only) | Azure Speech-to-Text (batch) | For spoken, real-time conversations use a Foundry voice agent (`agent_type: voice`, preview, explicit user opt-in only), not this row |
- **Capacity (TPM)**: e.g. `50K` GlobalStandard for `gpt-5.4`, `120K` for `gpt-5.4-mini`, `300K+` for high-volume
- **Reasoning effort** (for capable models): `minimal` | `low` | `medium` | `high` (default `medium`)

> **Do NOT use `GPT-4o` or `GPT-4o Vision`** — both are legacy as of May 2026.
> The `gpt-5.4` family supersedes them in every dimension (context, latency, vision
> quality, cost). If a SPEC carries forward a `GPT-4o` reference from an older
> template, that's a bug — sweep to **`gpt-5.4`** (default for pilots) or pick from
> the table above based on the capability profile.

> **Choosing the model / capacity / region behind this table** — see
> [`model-selection.md`](model-selection.md) in the design skill's references:
> the seven-decision procedure that fills `specs/foundation.md` § 2 and this
> section.

---

## 8. Human Interaction Points

Where humans are involved — approvals, escalations, input requests, feedback loops.

### [Interaction Name]
- **Trigger**: [When does this happen?]
- **Actor**: [Which human role?]
- **Channel**: [How — Teams, email, portal, chat?]
- **Data Presented**: [What the human sees]
- **Options**: [What actions can the human take?]
- **Timeout/SLA**: [How long before escalation?]
- **Action gate** (use the canonical taxonomy below): `approve` | `edit-and-approve` | `reject` | `escalate` | `signoff` | `audit-view` | `request-info`
  | Gate | Semantics | Typical UX |
  |------|-----------|------------|
  | `approve` | Yes/no on a proposed action | Adaptive Card with two buttons |
  | `edit-and-approve` | Human can amend the agent's proposal before approving | Editable form fields + approve button |
  | `reject` | Human refuses the action with a reason | Reason picker + free-text |
  | `escalate` | Human routes the case to a higher authority | Role/queue picker |
  | `signoff` | Human attests they reviewed (no veto) | Single confirm button + signature trail |
  | `audit-view` | Read-only inspection (no action taken) | Detail pane with audit log |
  | `request-info` | Human asks the customer/external party for more data | Templated message composer |
- **Linked business rules**: [BR-XXX list] — which rules require this gate

> **INPUT CONTRACT for `threadlight-hitl-patterns`.** The action gate
> drives Adaptive Card generation and bot UX. The linked BR-XXX list drives
> the audit trail wiring.

---

## 8b. Human Interaction (Workspace UX)

> **INPUT CONTRACT for `threadlight-workspace-ui`.** This section describes the
> case-management surface that humans use day-to-day — independent of the chat/Teams
> approval gates above. Skip this section if humans only interact via approval cards.

- **Workspace shape**: `case-list` (queue of items, filter/sort, click into detail) | `inbox` (chronological stream) | `dashboard` (KPI tiles + drill-down) | `console` (live ops with action toolbar) | `kanban` (stages with drag) | `map` (geo) | `none`
- **Primary filters**: list (e.g. status, owner, age, risk-band)
- **Detail pane sections** (top to bottom): list (e.g. summary card, agent reasoning trace, tool call log, decision history, action toolbar, audit viewer)
- **Action toolbar** — gates from § 8 that appear here (subset)
- **Audit viewer**: `inline` (always visible) | `drawer` (open on demand) | `none`
- **Bulk operations**: list (e.g. assign-to-me, batch-reject) — or `none`

---

## 9. Success Criteria

### Functional
- [ ] [Expected behavior — tied to business rules]

### Performance
- [Throughput, latency, SLA targets]

### Quality
- [Accuracy, error rates, coverage targets]

### Evaluation Scenarios

| ID | Scenario | Input | Expected Output | Business Rules | Category | Question type |
|----|----------|-------|-----------------|----------------|----------|---------------|
| S-001 | | | | BR-XXX | happy-path / edge-case / error / approval | lookup / multi_hop / negation / aggregation / thematic |

> **Relational questions.** When the process involves relational questions
> (or § 7 sets `Enrichment: entity_graph`), at least 30% of the eval set must
> be `multi_hop`, `negation` or `aggregation`, each with ground truth
> (`expected` or `expected_entities`), and results are reported per-type.
> Make the eval corpus large enough that the knowledge base cannot return
> most of the corpus in one retrieval; otherwise plain retrieval looks perfect
> for the wrong reason. Check the mix and score per type with
> `threadlight-evals/scripts/question_types.py`. For non-relational processes
> the column is optional and the default path is unchanged.

### Business KPIs (BR → KPI mapping)

> **INPUT CONTRACT for `microsoft-foundry` continuous-loop.** Every BR-XXX should
> map to at least one **measurable KPI** that can be computed from agent traces
> (Application Insights). This is what the continuous evaluation dashboard
> watches week-over-week — not just the binary scenario pass/fail.
>
> **Use the industry-native KPI vocabulary** from `references/data-realism/{industry}.md` § "<industry>-native KPIs". Generic names like `auto_decline_rate` should be the exception — most processes have a domain-recognized KPI an SME will accept on first read.

**Industry exemplars** (replace these with KPIs from the relevant industry file):

| Industry | Example KPI (good) | Example KPI (bad) |
|----------|--------------------|-------------------|
| FSI / AML | `alert_to_case_conversion_rate`, `l1_false_positive_rate`, `sar_filing_cycle_days_p50` | `decline_rate` |
| FSI / KYC | `edd_throughput_cases_per_analyst_per_day`, `first_touch_resolution_pct` | `auto_decline_rate` |
| Mfg / Plant | `oee_pct`, `first_pass_yield_pct`, `dpmo`, `capa_closure_cycle_days_p50` | `quality_score` |
| Mfg / Supply | `otif_pct_inbound`, `single_source_pct_of_spend` | `supply_score` |
| Retail / PIM | `pim_completeness_pct`, `time_to_publish_hours_p95` | `enrichment_rate` |
| Retail / Returns | `return_cycle_time_business_days_p50`, `restock_a_pct` | `return_resolution_rate` |
| Telco / Order | `order_fallout_rate_pct`, `fallout_mttr_hours_p50` | `order_success_rate` |
| Telco / Network | `mttr_hours_p1`, `first_call_resolution_pct` | `incident_resolution_rate` |

| BR | KPI Name | Formula (computable from traces) | Target | Alert threshold |
|----|----------|-----------------------------------|--------|-----------------|
| BR-001 | `<industry-native-kpi>` | `count(decisions where outcome=...) / count(decisions)` | (industry benchmark from data-realism file) | (alert when off-baseline) |
| BR-007 | `policy_citation_rate` | `count(answers where citations≥1) / count(answers)` | 100% | <95% |
| BR-012 | `human_escalation_rate` | `count(escalated) / count(decisions)` | (industry-realistic band) | (off-baseline) |

> Trace fields the agent must emit (declared in the skills' procedures):
> `decision.outcome`, `decision.business_rules_fired`, `answer.citations[]`,
> `escalation.reason`, etc. The continuous-loop ACA job pulls these from
> App Insights, computes KPIs, and writes back to a workbook + raises
> alerts on threshold breaches.

---

## 10. Trigger & Run Model

How and when the process executes.

- **Trigger**: [on-demand / scheduled / event-driven / continuous]
- **Schedule**: [If scheduled — cron expression or cadence]
- **Event source**: [If event-driven — what triggers it]
- **Expected volume**: [Requests per hour/day]
- **Latency/SLA**: [Max acceptable response time]
- **Concurrency**: [Parallel execution expected?]

### 10b. Triggers (Receiver contract)

> **INPUT CONTRACT for `threadlight-event-triggers`.** For event-driven and
> scheduled processes, declare the receiver shape so the right ACA job /
> Function / Event Grid sub / Service Bus consumer can be scaffolded.

| Trigger source | Receiver type | Idempotency key | Dedup window | Dead-letter rule |
|----------------|---------------|-----------------|--------------|------------------|
| Cron `0 6 * * *` | ACA Job | run timestamp | n/a | retry 3× then alert |
| Event Grid topic `orders/created` | Function (HTTP receiver) | `event.id` | 5 min | DLQ to Storage Queue |
| Service Bus queue `claims-incoming` | ACA consumer (Service Bus binding) | `MessageId` | 24h | move to `claims-poison` after 5 attempts |
| Webhook from external system | ACA Job (HTTP-triggered) | `X-Request-Id` header | 10 min | return 5xx to trigger sender retry |

> **Note for pilots:** event-driven triggers are **worth declaring** but **not mandatory
> to build for the first pilot** — the customer often integrates with their own event
> bus on their own terms. Ship the contract; let the integration follow.

---

## 11. Security, Compliance & Governance

- **PII involved**: yes / no — [if yes, what fields, with citation to the
  governing regime (HIPAA Safe Harbor § 164.514, GDPR Art 9, CPNI 47 CFR
  Part 64 Subpart U, PCI-DSS v4.0, etc.)]
- **Auth model**: [How users/systems authenticate — keyless / managed
  identity end-to-end is the default; any deviation is a flag]
- **Data residency**: [Customer expectation — `EU`, `US`, `UK`, `India`,
  `multi-region`. Names the Azure regions chosen. GDPR / PIPL / DPDPA
  compliance implications.]
- **Data retention**: [How long to keep agent traces, case data, audit
  events; deletion policy; right-to-be-forgotten path]
- **Regulatory**: [GDPR, HIPAA, SOX, FFIEC, MiFID II, PCI-DSS, ISO 27001,
  SOC 2 Type II, IATF 16949, GxP, ITAR/EAR, industry-specific — or
  `none` for internal automation only]
- **Access control**: [RBAC matrix — who can run this, who can see
  results. Reference Easy Auth / Entra ID groups by name.]
- **Audit requirements**: [What must be logged for auditability —
  decision rationale, citations, model+prompt version, human-overrides,
  upstream/downstream data lineage. Default: 7-year retention for
  regulated; 90-day for unregulated.]
- **Responsible AI posture**: [Risk tier per Microsoft RAI Standard v2
  (`limited`, `general`, `consequential`, `restricted`); applicable RAI
  goals — fairness, reliability, privacy, transparency, accountability;
  GDPR Art 22 (automated-decision rights) implications if applicable]
- **Model governance**: [Model + prompt version pinning; promotion gate
  from dev→prod (eval pass threshold); rollback procedure; drift
  monitoring cadence]
- **Customer onboarding RACI**: [Who on the customer side is **R**esponsible /
  **A**ccountable / **C**onsulted / **I**nformed for this process —
  business sponsor, IT owner, security/compliance signoff, legal/privacy,
  ops handoff. Demos that don't name a sponsor don't fund.]
- **ROI hypothesis**: [Quantifiable lever — `FTE-hours × loaded-rate`,
  `revenue-at-risk × probability`, `regulator-fine-avoided`, `cycle-time-
  compression × volume`. Cite the formula explicitly so the customer can
  replace the inputs with their own numbers.]
- **Change management**: [Org-side adoption plan — who trains the L1/L2
  analysts, how the agent's recommendations enter the existing workflow
  (parallel-run period? shadow-mode? full cutover?), what KPIs prove
  adoption stuck.]

### 11a. Runtime Governance Contract

> **INPUT CONTRACT for runtime governance design.** Validate this machine-readable
> fragment against `references/governance-contract.schema.json`. `governance.mode`
> exact contract text: `mode: off | selective | comprehensive`. `off` and `selective` are allowed;
> `comprehensive` is only valid when every consequential or unknown tool has a
> supported runtime binding. `off` means `lifecycle_bindings: []` and no bound
> tool records. `environment_modes only matter when mode != off`; `off` in
> `production-bound` is still allowed by design but does not make an enforcement
> claim. Legacy string tools remain valid where older
> manifests still permit them, but in this contract they are explicitly
> `unknown/unbound` until upgraded to the structured form below.
>
> **Layering vocabulary.** **SAFE is the methodology**. **ACS is the PDP**.
> **Agent Hooks is the runtime contract**. **host/gateway is the PEP**.
> **AGT is the toolkit**. **ASSERT is the assurance layer**. policy bundles, templates, and CI checks do not enforce runtime behavior on their own; they
> only prove whether the live PDP + PEP path is designed and verified correctly.

```yaml
framework: github-copilot-sdk | microsoft-agent-framework

governance:
  # Exact contract text:
  #   mode: off | selective | comprehensive
  mode: selective
  # environment_modes only matter when mode != off
  environment_modes:
    development: evaluate_only
    staging: evaluate_only
    preproduction: enforce
    production: enforce
  lifecycle_bindings:
    - lifecycle_point: input         # input | pre_model_call | post_model_call | pre_tool_call | post_tool_call | output | startup | shutdown
      policy_binding: request-ingress-v1
      enforcement_path: governed-tool-gateway
      safe_principles: [scope, audit]
      requires: [signed-policy-bundle]
    - lifecycle_point: output
      policy_binding: response-egress-v1
      enforcement_path: governed-tool-gateway
      safe_principles: [egress-review, audit]
      requires: [decision-receipt]

tools:
  - id: returns_get_case
    consequence: read                # read | write | external-egress | irreversible | unknown
    policy_binding: none             # use `none` only for an explicit unbound gap
    enforcement_path: none           # none | local-agent-hooks | governed-tool-gateway
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
  - id: returns_apply_decision
    consequence: write
    policy_binding: returns-write-v1
    enforcement_path: governed-tool-gateway
    intervention_points: [pre_tool_call, post_tool_call]
    safe_principles: [scope, approval, audit]
    requires: [human-approval-record, signed-policy-bundle]
  - id: legacy_export
    consequence: unknown
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [audit]
    requires: [operator-review]
    acceptance_record:
      owner: risk-owner@contoso.com
      justification: Temporary waiver while a supported binding is being onboarded.
      review_date: "2026-09-04T00:00:00Z"
      expiry: "2026-12-31T00:00:00Z"
```

- `development: evaluate_only` and `staging: evaluate_only` are fixed design-time
  expectations; `preproduction: enforce` and `production: enforce` are fixed
  release expectations when `mode != off`.
- If a tool can **write**, perform **external-egress**, or trigger an
  **irreversible** outcome, classify it explicitly and recommend the strongest
  supported binding.
- If the operator selected a runtime whose supported bindings cannot satisfy the
  recommended policy path, surface that as a design decision. Offer MAF if it
  would satisfy the requirement, but do not silently switch runtimes in the
  spec.
- `production-bound` unbound consequential or unknown tools require an
  `acceptance_record` with `owner`, `justification`, `review_date`, and
  `expiry`, both recorded as quoted RFC3339 timestamps. `off` is still allowed
  in `production-bound`, but it does not make an enforcement claim and any
  consequential or unknown unbound tool still needs acceptance.

#### Fast-PoC (recommend-only) variant

A Fast-PoC exposes read tools only: the agent proposes the decision with
citations and a person records or applies it (SPEC § 8). Governance is not
selected and every read stays unbound; `specs/manifest.json` carries
`"action_mode": "recommend-only"`. Adding a write tool is the Production path
(Full-mode design, then `threadlight-govern`), never an unbound write.

- **Action mode**: `recommend-only` (governance not selected; reads unbound;
  no consequential tool is exposed)

```yaml
framework: github-copilot-sdk

governance:
  mode: off
  environment_modes:
    development: evaluate_only
    staging: evaluate_only
    preproduction: enforce
    production: enforce
  lifecycle_bindings: []

tools:
  - id: returns_get_case
    consequence: read
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
  - id: return_policy_search
    consequence: read
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
```

#### Workshop governed-write variant

One write shown live through the governed tool gateway; every other tool stays
an unbound read. `specs/manifest.json` carries `"action_mode": "governed-write"`.
The contract never requires `approval`: escalation approval is selected in the
signed gateway registry (`approval_mode: deferred`, `approval_requirement: policy`).

- **Action mode**: `governed-write` (one write through the governed tool
  gateway; every other tool is an unbound read)
- **Policy rules** (`returns-recommendation-write-v1`, implemented in Rego by `threadlight-govern`):
  - `BR-001` allow: in-window return under EUR 250 with a cited RP clause.
  - `BR-002` deny: outside the return window or without a cited clause.
  - `BR-003` escalate: refund above EUR 250; a person approves with
    `threadlight-review-action` (or the Outlook approval opt-in).
- **Downstream service**: `POST /cases/{rma_id}/recommendation` (idempotency
  key `rma_id`) and `GET /cases/{rma_id}/recommendation` (outcome); it
  authorizes the gateway identity separately.
- **Governance foundation**: the shared control plane, gateway, Key Vault
  signing key and Cosmos audit/approvals exist before deploy (deployed once
  per tenant by the facilitator); the gateway gets a central audit ACK before
  the effect.

```yaml
framework: github-copilot-sdk

governance:
  mode: selective
  environment_modes:
    development: evaluate_only
    staging: evaluate_only
    preproduction: enforce
    production: enforce
  lifecycle_bindings: []

tools:
  - id: returns_get_case
    consequence: read
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
  - id: return_policy_search
    consequence: read
    policy_binding: none
    enforcement_path: none
    intervention_points: []
    safe_principles: [least-privilege]
    requires: []
  - id: returns_record_recommendation
    consequence: write
    policy_binding: returns-recommendation-write-v1
    enforcement_path: governed-tool-gateway
    intervention_points: [pre_tool_call]
    safe_principles: [scope, audit]
    requires: [authorization, signed-policy-bundle, decision-receipt, idempotency-or-transaction]
```

### 11b. AI Governance Hub Posture (opt-in spoke)

> **INPUT CONTRACT for the optional governance-hub spoke handoff in
> `threadlight-deploy`.** Every regulated process should declare whether
> it needs to land as a spoke against an AI Governance Hub (e.g. an
> internal central LLM gateway / policy plane). The deploy flow generates
> the standalone agent first; if `governance_hub.required` is true,
> deploy then runs the spoke-onboarding handoff as a separate, opt-in
> step.

- **Governance hub spoke required**: `yes` (FSI, healthcare, regulated supplier risk) | `no` (PoC, internal automation)
- **Reason**: [Why — regulator audit, central LLM gateway policy, Key Vault federation, RAI policy enforcement, etc.]
- **Spoke artifacts needed**: list (e.g. `Access Contract`, `APIM connection`, `Key Vault secret federation`, `Product Policy`, `JWT auth`, `network whitelist`)
- **Tenant strategy**: `shared demo tenant` (default) | `dedicated customer tenant` | `customer-deferred`

---

## 11c. Tech Stack (Module selectors)

> **INPUT CONTRACT for `threadlight-deploy/references/azd-modules` Bicep module library and the
> composer in `threadlight-deploy`.** This selector vocabulary is the
> **canonical source of truth** — both the `threadlight-deploy/references/azd-modules` module library
> and the `threadlight-deploy` Phase-6 composer must read from this list
> verbatim. If you change a selector name, change it here first.
>
> Declare which infra modules the process needs. Don't list modules the
> process doesn't need (every selected module costs money).

| Module | Selected? | Purpose in this process |
|--------|-----------|-------------------------|
| `cosmos-db` | yes/no | Persistent case state, audit log, agent memory (no for stateless single-call agents) |
| `ai-search` | yes/no | Foundry IQ Knowledge Base backing |
| `doc-intel` | yes/no | Structured document extraction (passport, invoice, ID — when prebuilt model fits) |
| `azure-vision` | yes/no | OCR / image analysis (when not using GPT vision) |
| `azure-speech` | yes/no | Batch speech-to-text / text-to-speech of files only (voice agents use `agent_type: voice` with an explicit user opt-in, not this module) |
| `event-grid` | yes/no | Pub/sub for trigger events |
| `service-bus` | yes/no | Reliable queueing for case workflow |
| `storage-blob` | yes/no | Document upload, large artifacts, dataset hosting |
| `app-insights` | yes (default) | Telemetry — required for continuous evals |
| `aca-job` | yes/no | Scheduled / event-triggered batch work |
| `aca-mcp` | yes/no | Custom MCP server (mock or real) |
| `aca-bot` | yes/no | Teams bot |
| `foundry-iq-index` | yes/no | Pre-provisioned Knowledge Base + chunked corpus |

**Always-created** (not selectable): shared **UAMI** (managed identity),
the **Foundry project** + agent definition, the **ACR** for container
images.

**Implications** (the composer enforces these — declare them so SPEC
review can sanity-check):
- Selecting `aca-bot` implies `aca-mcp` (bot needs MCP for case lookups)
- Selecting `event-grid` or `service-bus` implies `aca-job` (you need a
  receiver)
- Selecting `foundry-iq-index` implies `ai-search` and `storage-blob`
- Selecting `azure-speech` with custom voice / custom model implies
  `azure-speech-custom-subdomain` (**IRREVERSIBLE** flag — the deploy
  script must surface a `--confirm-irreversible` confirmation)

**Keyless by mandate.** `key-vault` is **not** in the always-created or
default-selected list. Threadlight pilots use managed identity end-to-end
per the keyless-mandate; add Key Vault only when the process integrates
with a customer-side service that demands a literal API key (and document
that integration explicitly in § 5).

---

## 11d. Demo Data (Realism rules)

> **INPUT CONTRACT for `threadlight-demo-data-factory`.** Sample data shape
> beyond the basic schema in § 4.

- **Per-entity volume**: e.g. `customers: 50, orders: 200, alerts: 1000`
- **Distribution**: realistic skew (e.g. `80% low-risk / 15% medium / 5% high`)
- **Golden cases** (named, hand-curated for the demo script): e.g. `kyc-cardinal-aerospace-holdings` (premium corporate onboarding, edge-case UBO chain), `fault-pinewood-gnb-overload-2026-04-15` (cascading failure for the dashboard demo). Naming **must** follow the two-token-shift rule from `references/data-realism/README.md` — no `acme-*` or `contoso-*`.
- **Reset semantics**: `idempotent` | `append-only` | `none` (see § 5b)
- **Realism rules** (industry-specific — see `references/data-realism/{industry}.md`):
  - PII: [allowed / synthetic-only / none]
  - Vendor / brand names: [synonym-shifted / fully fictional]
  - Regulatory identifiers (SSN, IBAN, etc.): [valid-format-fake / pattern-only]
  - Geographic distribution: [single-country / multi-region / global]

---

## 11e. Workflow Model

> **INPUT CONTRACT for `threadlight-deploy` Phase 2.** Selects the deploy
> route. `workflow` routes to MAF + Responses; deploy generates the MAF
> Agent container (workflow-graph generation is not shipped). Defaults to `agent` when absent. Also carries the
> `capability_signals` block that `threadlight-deploy`'s Runtime-policy
> pre-flight cross-checks against `specs/foundation.md § 1` before route
> validation — the two must stay consistent (see
> `references/runtime-policy.json`'s `blocked_when`).

```yaml
agent_type: hosted  # hosted | prompt | voice | harness. Foundry hosted agent is the default; see _shared/foundry-only-agents.md
trivial_justification: null  # REQUIRED when agent_type: prompt (explicit opt-in only): one model, no custom code tools,
                             # no multi-step orchestration, no state beyond the Foundry thread
prompt_opt_in_source: null   # REQUIRED when agent_type: prompt: must be `user` (an agent-written value is not an opt-in)
prompt_opt_in_evidence: null # REQUIRED when agent_type: prompt: quote of, or reference to, the user's explicit request
voice_opt_in_source: null    # REQUIRED when agent_type: voice or voice_frontend: hosted-voice: must be `user` (an agent-written value is not an opt-in)
voice_opt_in_evidence: null  # REQUIRED when agent_type: voice or voice_frontend: hosted-voice: quote of the user's spoken-conversation requirement
preview_acknowledged: null   # REQUIRED when agent_type: voice, harness or voice_frontend: hosted-voice: must be `true` (these are preview)
harness_opt_in_source: null   # REQUIRED when agent_type: harness: must be `user` (an agent-written value is not an opt-in)
harness_opt_in_evidence: null # REQUIRED when agent_type: harness: quote of the user's request for the Foundry Copilot harness (preview)
harness_fit:                 # REQUIRED when agent_type: harness: every answer known; any disqualifier or null forces hosted (runtime-policy.json harness_disqualifiers)
  read_mostly: null                   # advisory only: false means every consequential write needs a seam
  citadel_model_path_required: null   # true disqualifies: the harness has no BYOM through AI Gateway
  acs_in_process_pep_required: null   # true disqualifies: no Agent Hooks surface for an in-process ACS PEP
  foundry_memory_required: null       # true disqualifies: Foundry Memory is not available with the harness
  voice_frontend_required: null       # true disqualifies (also voice_frontend: hosted-voice)
  region: null                        # a documented harness region, e.g. swedencentral (eastus2 is not one)
  consequential_write_seam: null      # none | function-tool | governed-mcp; anything else disqualifies
voice_frontend: none          # none | hosted-voice. Opt-in voice front-end (Foundry Hosted Voice, preview) on the hosted agent; item 2c
voice_name: null              # optional with voice_frontend: hosted-voice: Azure voice, e.g. it-IT-IsabellaMultilingualNeural (default en-US-AvaMultilingualNeural; multilingual voices speak the caller language)
voice_hold_text: null          # optional with voice_frontend: hosted-voice: hold message spoken during slow tool turns, in the voice's language
copilot_builtin_tools: none    # none, or Copilot CLI built-ins by name (web_fetch, view, glob, grep or rg, bash, create, edit, sql, task); GHCP agents otherwise get only their MCP tools and skills
copilot_builtin_tools_opt_in_source: null  # REQUIRED with copilot_builtin_tools: must be `user`
copilot_builtin_tools_reason: null         # REQUIRED with copilot_builtin_tools: why the process needs it, e.g. "read the public returns policy page"
workflow_model: agent  # agent | workflow

capability_signals:                     # machine-readable booleans + unresolved markers runtime-policy.json keys on
  requires_toolbox: false               # curated multi-tool Foundry Toolbox (web_search, code_interpreter, ...)
  requires_custom_python_tools: false   # bespoke @tool Python functions beyond MCP passthroughs
  requires_file_generation: false       # agent must produce/return files (XLSX/PDF/CSV), not just text/JSON
  latency_sensitive_data_queries: false # sub-second/fast data lookups where MAF agent tooling outperforms
  unresolved_signals:                   # per-signal unknown marker — a listed name means its boolean above is a placeholder, not a decision
    - requires_toolbox
    - requires_custom_python_tools
    - requires_file_generation
    - latency_sensitive_data_queries
  source: open-question                 # provided | inferred | defaulted-after-skip | open-question | migrated-from-legacy-foundation | hand-crafted-deploy-inferred
```

- `agent` *(default)* — single agent with tools; `threadlight-deploy`
  generates `AGENTS.md` + Skills + a Foundry hosted-agent container.
- `agent_type` is restricted to `hosted` (always the default), `prompt`, `voice` or `harness`.
  `prompt` requires an explicit opt-in from the user, recorded as
  `prompt_opt_in_source: user` with `prompt_opt_in_evidence` quoting the request.
  An agent-written `agent_type: prompt` without that user provenance is not an
  opt-in: treat it as `hosted`. Never pick a prompt agent on your own initiative, and
  never when refusing an app-side request (that routes to `hosted`). Even with
  the opt-in, use `prompt` only when every trivial criterion in
  [`foundry-only-agents.md`](../../_shared/foundry-only-agents.md) holds, and
  record `trivial_justification`. An agent loop in application code (ACA, App
  Service, Functions, a web app, or direct Responses / Chat Completions tool
  loops) is never a valid value. `voice` (a Foundry voice agent, preview) needs an
  explicit opt-in from the user who requires a spoken, real-time conversation:
  `voice_opt_in_source: user`, `voice_opt_in_evidence` and
  `preview_acknowledged: true`. An agent-written `agent_type: voice` without that
  user provenance is not an opt-in: treat it as `hosted`. The official
  `microsoft-foundry` skill (create-voice) builds it. `harness` (a prompt agent on
  the Foundry Copilot harness, preview) needs the same kind of user opt-in:
  `harness_opt_in_source: user`, `harness_opt_in_evidence`,
  `preview_acknowledged: true` and a `harness_fit` record with every answer known.
  An agent-written `agent_type: harness` without that user provenance is not an
  opt-in: treat it as `hosted`. Any disqualifier or unknown fit answer also forces
  `hosted` (item 2d of
  [`foundry-only-agents.md`](../../_shared/foundry-only-agents.md)). Other
  preview-only Foundry features are out of scope.
- **Harness fit verdict.** Whenever `harness_fit` is answered (the user asked
  about the Foundry Copilot harness, or `agent_type: harness`), render the
  verdict block below from the `harness_disqualifiers` in
  [`runtime-policy.json`](runtime-policy.json); never hand-write it. A `fit`
  verdict is not an opt-in: the harness still needs the user's request.

- `voice_frontend: hosted-voice` keeps `agent_type: hosted` and adds a spoken
  front-end (Foundry Hosted Voice, preview): a managed `kind: voice` wrapper uses
  the GHCP hosted agent as its conversation engine, so tools and governance stay
  in the text agent. It needs the same user opt-in fields as `voice`; an
  agent-written `voice_frontend` is not an opt-in and the agent stays text-only.
  Default `none`. See item 2c of
  [`foundry-only-agents.md`](../../_shared/foundry-only-agents.md).
- `copilot_builtin_tools` stays `none` by default: a GHCP hosted agent exposes
  only its SPEC MCP tools, custom tools and skills, never the Copilot CLI
  built-ins (shell, file edits, web fetch, sub-agents). Name a built-in only
  when the process needs it and the user asked for it
  (`copilot_builtin_tools_opt_in_source: user` plus a reason); an
  agent-written value is ignored.
- `workflow` — deterministic multi-step orchestration; the SPEC adds
  `WORKFLOW.md` (executor / phase definitions) as the target design, and
  `threadlight-deploy` generates the MAF Agent container on Responses that
  follows that phase order through its instructions and HITL tools
  (workflow-graph generation with typed executors is not shipped). Use when
  the process has fixed phases, long-running waits, retries with explicit
  back-off, or human approvals between stages.

#### Harness fit verdict

Render with `python <threadlight-skills>/skills/_shared/agent_type_policy.py --spec specs/SPEC.md --verdict-md`
(in Cowork, apply the `harness_disqualifiers` and `harness_fit_questions` of
`runtime-policy.json` by hand, the same way). The verdict is `fit` (no
disqualifier hit), `not-fit` (one row per disqualifier, an unknown answer counts
as a hit) or `not-assessed` (no `harness_fit` answers); advisories such as
"not read-mostly" never change it. Cost lines for the harness come from
`threadlight-qualify` (`harness-model-tokens`, `harness-sandbox`, each labelled
estimated or measured). A `fit` verdict is not an opt-in.

```markdown
**Harness fit verdict: <fit | not-fit | not-assessed>**

| Reason | Kind |
| --- | --- |
| <disqualifier id: harness_fit.<field>=<answer> (reason)> | disqualifier |
| <advisory> | advisory |
```

### Agent topology (one agent with skills, or several agents)

Decision guide and citations: `references/process-traits.md` (Agent Topology). Default and
recommendation: `single-agent-with-skills` with an empty `split_triggers` list.

```yaml
agent_topology:
  decision: single-agent-with-skills   # single-agent-with-skills | multi-agent
  split_triggers: []                   # empty for single agent; else any of security-compliance-boundary,
                                       # separate-owning-team, independent-release-cadence, measured-single-agent-limit
  inter_agent_protocol: none           # none | a2a | maf-workflow-in-hosted-agent
  criteria:                            # one short note each, from the process walk-through
    latency_hops: "[model round trips per user turn and whether the user waits on them]"
    sessions: "[where conversation state lives; any context that must stay isolated]"
    quota: "[model deployments and TPM pool each agent draws from]"
    failure_points: "[what breaks a turn; retry and fallback owner]"
    cost: "[context processed once vs per agent; prototype evidence if a split is claimed cheaper]"
    ownership_boundary: "[teams that own and release each part]"
    governance_boundary: "[identities, permissions, data classification, separation of duties]"
    eval_complexity: "[eval suites needed: one agent, or per agent plus end-to-end hand-offs]"
  agents: []                           # multi-agent only: [{name, spec, owner, identity, data_boundary}]
  rationale: "[why this decision; name the trigger and its evidence when multi-agent]"
  source: open-question                # provided | inferred | open-question
```

- `multi-agent` requires at least one `split_triggers` entry with evidence in
  `rationale`. Each agent gets its own SPEC and pilot; Threadlight does not
  generate the inter-agent wiring, so record it as an open item in § 13.
- `maf-workflow-in-hosted-agent` is orchestration inside one hosted agent: keep
  `decision: single-agent-with-skills` and use `workflow_model: workflow`.

> **Deriving `capability_signals`.** Set each boolean from what discovery
> actually found: `false` only when the requirement or tooling is **confirmed
> absent**, never merely unknown. If discovery cannot determine a signal yet,
> leave its name in `unresolved_signals` (`source: open-question`) instead of
> guessing `false`. As each signal resolves, **remove** its name from
> `unresolved_signals` and set its boolean accurately — an **empty**
> `unresolved_signals` list means all four are resolved. This block mirrors
> `specs/foundation.md § 1` verbatim; the two must stay consistent. **Refuse**
> to honor an explicit `explicit-supported-choice` GHCP override while
> `unresolved_signals` is non-empty (`runtime-policy.json`'s
> `requires_resolved_signals` gate on that route) — an unresolved signal could
> still turn out to be the one a `blocked_when` route owns.

---

## 11f. Deployment Posture

> **INPUT CONTRACT for `threadlight-deploy` Phase 1.5.** When this block is
> populated, Phase 1.5 takes **Path 1** — proceed with matching posture
> defaults, no operator prompt. When absent, Phase 1.5 asks the operator
> once and writes the answers to `specs/deployment-posture.md`.
> Pre-populated by `threadlight-design` Step 1.5 (Full mode); left empty
> by Fast-PoC.

```yaml
deployment_posture:
  deployment_target: demo-sandbox | customer-pilot | production-bound
  source: provided | inferred | defaulted-after-skip | open-question
  overrides:
    networking: public | private-required | deferred
    replicas: single | ha-min-replicas
    retention: 90d | regulated-7y | customer-defined
    model_pinning: preview-ok | ga-pinned
  deferred_decisions:
    - waf-front-door
    - dr-runbook
```

- `deployment_target` is the primary lever. The other rows are
  posture-tuning overrides; each may be omitted (deploy applies the
  defaults for the chosen target).
- `source` documents how the value was reached — same taxonomy as § 13.
- `deferred_decisions` lists rows the operator acknowledged but cannot
  implement in this pilot's scope (e.g. WAF / Front Door, paired-region
  DR). `threadlight-deploy` surfaces them as
  `<!-- TODO(posture): ... -->` comments in `main.bicep`.

**Authority order** (drift mitigation): SPEC § 11f → `specs/deployment-posture.md`
→ `azd env` vars. On rerun, `threadlight-deploy` Phase 1.5 reads the
posture file first; if § 11f also exists and disagrees, it surfaces the
conflict and asks which wins.

---

## 12. Production Readiness

> **INPUT CONTRACT for `threadlight-production-ready`.** Populated by
> default in the design template — fill in the placeholders before the
> pilot moves into customer architecture review. The production-readiness
> skill reads this block to resolve the target posture (Citadel spoke /
> AGT / standard AI gateway / hybrid), to score residency and SLA
> commitments, and to drive the customer-facing hand-off report.
> Pilots that ship with this section empty default to
> `target_posture: standard-ai-gateway` and trigger a "Recommended
> enterprise posture: Citadel-spoke" callout in the report.

- **target_posture**: `citadel-spoke` | `agt` | `standard-ai-gateway` | `hybrid` | `unset`
  - Citadel-spoke = the recommended enterprise default when the customer
    has (or is bringing) an AI Hub Gateway. AGT = in-process middleware
    where there is no hub. Standard AI gateway = third-party fallback.
    Hybrid = both AGT and an upstream APIM hub.
- **residency**: `EU` | `US` | `UK` | `India` | `multi-region` (cite the chosen Azure regions)
- **rto**: `4h` | `1h` | `15m` | … (recovery time objective)
- **rpo**: `1h` | `15m` | `0` (recovery point objective; `0` means synchronous replication required)
- **sla**: `99.5` | `99.9` | `99.95` (% availability target)
- **incident_owner**: `oncall@customer.com` (single mailbox / on-call rotation; not "TBD")
- **production_track**: `pilot-to-prod-2-week` | `production-hardening-6-week` | `not-bound` (timeline declared by customer)
- **must-have pillars**: list — pick from `network-posture, agent-governance, identity-access, secrets, observability, continuous-evals, responsible-ai, hitl-audit, supply-chain, cost, reliability, sre-handover, model-lifecycle`
- **CISO sign-off required**: `yes` (regulated industry, customer-data) | `no` (internal automation, demo-only)
- **Waiver acceptors**: list of names+titles (people who can sign off a waiver). Empty = nobody can; every gap is a hard block.

### `load_profile{}` (consumed by `threadlight-consumption-iq`)

> **Seed from qualification when available.** If a
> `qualification/sizing-manifest.json` exists (produced by `threadlight-qualify`),
> seed this block directly from its normalized `load_profile` instead of
> repeating the interview — copy `workload_class`, `peak_requests_per_second`,
> `business_hours_only`, `pages_per_month`/`storage_gb_year_one`, and the pinned
> region across, and record the sizing manifest as the provenance. Only fall
> back to the `threadlight-consumption-iq` wizard when no sizing manifest exists.
>
> Until either is run, recommendations and projections are not produced.

```yaml
load_profile:
  workload_class:               # chat-agent | batch | scheduled | hybrid
  peak_concurrent_sessions:     # int >= 1
  avg_requests_per_session:     # int >= 1
  avg_tokens_per_request:       # int >= 1 (combined input + output)
  peak_requests_per_second:     # float >= 0
  business_hours_only:          # bool
  cosmos_gb_year_one:           # float >= 0
  storage_gb_year_one:          # float >= 0
  ai_search_documents:          # int >= 0
  monthly_growth_rate:          # float >= 0 (e.g. 0.15 = 15%/mo)
  declared_constraints:
    max_p95_latency_ms:         # int >= 0
    min_redundancy:             # none | zone-redundant | geo-redundant
    pinned_region:              # optional; ISO Azure region like eastus2
```

> See `skills/threadlight-production-ready/references/spec-section-12-template.md`
> for two fully-worked examples (Citadel-spoke FSI customer and AGT-only
> internal automation).

---

## 13. Assumptions & Open Questions

> **Source-taxonomy table.** Every captured-context item from § 1
> (`audience_mode`, `customer.*`), every § 11f posture override, and any
> downstream-skill default that was applied without explicit input MUST
> appear here with a `Source` value of `provided | inferred |
> defaulted-after-skip | open-question`. This is the auditable trail of
> silently-defaulted decisions.

### Captured-context source table

| Field                          | Effective value                      | Source                | Default used? | Follow-up needed |
|--------------------------------|--------------------------------------|-----------------------|---------------|------------------|
| § 1.audience_mode              | [e.g. external-demo]                 | [provided / inferred / defaulted-after-skip / open-question] | yes / no | yes / no |
| § 1.customer.name              | [e.g. Contoso Retail]                | provided              | no            | no               |
| § 1.customer.region            | [e.g. EU]                            | provided              | no            | no               |
| § 1.customer.brand_palette     | [e.g. Threadlight neutral]           | defaulted-after-skip  | yes           | no               |
| § 11f.deployment_target        | [e.g. customer-pilot]                | provided              | no            | no               |
| § 11f.overrides.networking     | [e.g. public]                        | defaulted-after-skip  | yes           | yes              |

> Fast-PoC mode callout *(include verbatim when Step 1.5 was skipped)*:
> _Fast-PoC mode: audience mode, customer context, brand, and production
> posture were not collected; using neutral demo defaults. Override later
> in SPEC § 1 / § 11f / § 13._

> **Also add this row to the table above whenever § 14 ships blank** —
> always in Fast-PoC mode, and in Full mode whenever the operator has not
> yet confirmed `success_event` and the cost/variance thresholds. This is
> not a silent default (`Default used? no`): § 14 has no defaults at all,
> so leaving it blank is always the honest, correct state; this row is what
> makes that state auditable rather than merely implicit.
>
> | § 14.value_model | not collected | open-question | no | yes |
>
> **Full mode's job is to ask the operator to state and confirm
> `success_event` and every `baseline`/`maturity_policy`/`accounting`
> threshold explicitly, or to explicitly defer them here** — never to
> arbitrarily derive a number or event name just to avoid this row.

### Assumptions
- [Assumption 1 — something taken as given]
- [Assumption 2]

### Open Questions
- [Question 1 — needs stakeholder input]
- [Question 2]

### Dependencies
- [Dependency 1 — external system, team, or timeline]
- [Dependency 2]

---

## 14. Value Model

> **INPUT CONTRACT for the design → deploy cost-actuals reconciliation
> contract.** See `references/value-model-schema.md` for the full
> field-by-field schema, bounds, and rationale. This section is a **blank
> shape** — every field below is a bare YAML key, at most followed by a
> comment describing its type/bounds. Comments are not values: never invent
> a number to fill a placeholder. Copy the *shape* below, never the worked
> numbers from `examples/returns-triage-governed/specs/SPEC.md § 14` —
> those are specific to that pilot's return-triage economics and would be a
> fabricated default for any other pilot.
>
> **Full mode**: ask the operator to state and confirm each `maturity_policy`,
> `success_event`, `baseline`, and `accounting` field explicitly.
> `success_event` (`name` / `trace_attribute` / `success_values`) is always
> **operator-confirmed** in Full mode — never inferred from a BR-XXX business
> rule or guessed from the process description. A field the operator cannot
> answer yet stays blank and gets a row in § 13 Open Questions with
> `Source: open-question` — not a guessed number.
>
> **Fast-PoC mode**: emit this section's shape verbatim (every leaf blank,
> `success_event` included) and leave the source open in § 13 — unlike
> § 12's `target_posture`, this section has no silent default. An incomplete
> `maturity_policy` yields a `not-verified` cost verdict downstream, but the
> projection and actuals evidence artifacts are still produced and written;
> only the pass/fail verdict is withheld until the policy is satisfied.

```yaml
value_model:
  cost:
    maturity_policy:
      min_complete_days:                       # int >= 1
      min_successful_interactions:              # int >= 1
      min_cost_settlement_age_hours:            # int >= 0
      max_window_end_age_days:                  # int >= 1
      min_projection_attribution_coverage_pct:  # float, (0, 1] — this is
                                                 # PROJECTION attribution
                                                 # coverage, not actual
                                                 # resource-id coverage; only
                                                 # projection coverage is
                                                 # policy-gated here
    success_event:
      name:              # identifier: ^[A-Za-z][A-Za-z0-9_.:-]{0,127}$
                          # operator-confirmed in Full mode; never inferred
      trace_attribute:    # identifier: ^[A-Za-z][A-Za-z0-9_.:-]{0,127}$
                          # operator-confirmed in Full mode; never inferred
      success_values: []  # nonempty list of the same identifier grammar;
                          # operator-confirmed in Full mode; never inferred
    baseline:
      target_cost_per_successful_interaction_usd:  # float > 0; USD per
                                                     # successful interaction
                                                     # (as defined by
                                                     # success_event); no
                                                     # default
      max_forecast_variance_pct:                   # float, fractional [0, 1]
                                                     # (0.20 = 20%); no default;
                                                     # values > 1 are invalid —
                                                     # COST variance only
      max_token_volume_variance_pct:                # float, fractional [0, 1]
                                                     # (0.20 = 20%); no default;
                                                     # values > 1 are invalid —
                                                     # TOKEN VOLUME variance
                                                     # only; a distinct
                                                     # threshold from cost
                                                     # variance
    accounting:
      actual_cost_basis: usage-pretax    # literal; a metric/source, not a price basis
      actual_billing_price_basis:        # retail | ea | mca | unknown
      forecast_price_basis:              # retail | ea | mca
      allow_basis_mismatch_for_verdict:  # bool
      scope_policy:                      # dedicated_resource_group | tagged_allocation
```

> **Why `success_event.name` / `trace_attribute` / `success_values` are
> restricted to `^[A-Za-z][A-Za-z0-9_.:-]{0,127}$`**: these identifiers are
> compiled into a fixed AppTraces KQL query by the reconciliation code — the
> code never builds arbitrary KQL from operator input. Anything outside this
> grammar is rejected before it reaches the query string, not sanitized
> inside it. All three fields are **operator-confirmed** in Full mode and
> blank/open-question in Fast-PoC — never derived from a business rule or
> invented to look complete.
>
> **Why `max_forecast_variance_pct` / `max_token_volume_variance_pct` are
> fractional, not percentage integers**: `0.20` means 20%. Both fields are
> bounded to `[0, 1]`; a value greater than `1` (for example `20`, meant as
> "20 percent") is invalid and must be rejected, never silently
> reinterpreted. Neither field has a default.
>
> **Why `actual_billing_price_basis` is a required, explicit operator
> declaration and not derived**: the Cost Management Query API returns
> actual spend without telling you which price basis (retail / EA / MCA)
> produced it. The operator must state it. `unknown` is a valid but
> conservative choice — it is always treated as a basis mismatch against
> `forecast_price_basis` unless `allow_basis_mismatch_for_verdict: true`.
```
